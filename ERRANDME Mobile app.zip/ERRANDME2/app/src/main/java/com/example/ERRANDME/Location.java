package com.example.ERRANDME;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties

public class Location {

    private String locationID;
    private String locationLat;
    private String locationLong;
    private String locationAvailable;
    private String locationUserID;

    public Location() {
    }

    public Location (String locationID, String locationLat, String locationLong,
                     String locationAvailable, String locationUserID) {

        this.locationID = locationID;
        this.locationLat = locationLat;
        this.locationLong = locationLong;
        this.locationAvailable = locationAvailable;
        this.locationUserID = locationUserID;

    }

    public String getLocationID(){
        return locationID;
    }

    public String getLocationLat(){
        return locationLat;
    }

    public String getLocationLong(){
        return locationLong;
    }

    public String getLocationAvailable(){
        return locationAvailable;
    }

    public String getLocationUserID(){
        return locationUserID;
    }

}

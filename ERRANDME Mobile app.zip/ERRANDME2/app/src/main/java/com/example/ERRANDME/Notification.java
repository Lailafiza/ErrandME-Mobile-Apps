package com.example.ERRANDME;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Notification {

    private String notiID;
    private String notiCount;
    private String notiProgId;

    public Notification() {

    }

    public Notification(String notiID, String notiCount, String notiProgId) {

        this.notiID = notiID;
        this.notiCount = notiCount;
        this.notiProgId = notiProgId;
    }

    public String getNotiID() {
        return notiID;
    }

    public String getNotiCount() {
        return notiCount;
    }

    public String getNotiProgId() {
        return notiProgId;
    }
}
package com.example.ERRANDME;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Progress {

    private String progID;
    private String progService;
    private String progStatus;
    private String progTotPrice;
    private String progLat;
    private String progLong;
    private String progCustID;
    private String progDispID;

    public Progress() {

    }

    public Progress(String progID, String progService, String progStatus,
                    String progTotPrice, String progLat, String progLong, String progCustID, String progDispID) {

        this.progID = progID;
        this.progService = progService;
        this.progStatus = progStatus;
        this.progTotPrice = progTotPrice;
        this.progLat = progLat;
        this.progLong = progLong;
        this.progCustID = progCustID;
        this.progDispID = progDispID;
    }

    public String getProgID() {
        return progID;
    }

    public String getProgService() {
        return progService;
    }

    public String getProgStatus() {
        return progStatus;
    }

    public String getProgTotPrice() {
        return progTotPrice;
    }

    public String getProgLat() {
        return progLat;
    }

    public String getProgLong() {
        return progLong;
    }

    public String getProgCustID() {
        return progCustID;
    }

    public String getProgDispID() {
        return progDispID;
    }
}
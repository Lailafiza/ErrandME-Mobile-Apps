package com.example.ERRANDME;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class PaymentActivity extends AppCompatActivity {

    private TextView tvPService,tvDistanceKM, tvDPriceKM,tvweightKG, tvWPriceKG, tvIVechicle,
                        tvIFragile, tvITotal, tvIItem, tvPaymentShip;
    private Button btnPayback, btnPaysubmit;
    private RadioButton rbExpress, rbNormal;
    private Integer priceW, priceD, priceV, priceF, total;
    String myEmail,myDist, myType, myWeight, myFragile, myVehicle, frag, SLat, SLong, ELat, ELong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        tvPaymentShip = findViewById(R.id.tvPShip);
        tvPService = findViewById(R.id.tvService);
        tvDistanceKM = findViewById(R.id.tvDistKM);
        tvDPriceKM = findViewById(R.id.PriceKM);
        tvweightKG = findViewById(R.id.tvWeightKG);
        tvWPriceKG = findViewById(R.id.tvPriceKG);
        tvIVechicle = findViewById(R.id.tvinfoVechicle);
        tvIItem = findViewById(R.id.tvItem);
        tvIFragile = findViewById(R.id.tvinfoFragile);
        tvITotal = findViewById(R.id.tvinfoTotal);
        rbExpress = findViewById(R.id.fast);
        rbNormal = findViewById(R.id.reg);
        btnPaysubmit = findViewById(R.id.btnPaySubmit);
        btnPayback = findViewById(R.id.btnPayBack);

        myEmail = getIntent().getStringExtra("MailingPayment");
        myDist = getIntent().getStringExtra("Distance");
        myType = getIntent().getStringExtra("TypeShip");
        myWeight = getIntent().getStringExtra("Weight");
        myFragile = getIntent().getStringExtra("Fragile");
        myVehicle = getIntent().getStringExtra("VehiclingShip");
        SLat = getIntent().getStringExtra("StartLat");
        SLong = getIntent().getStringExtra("StartLong");
        ELat = getIntent().getStringExtra("EndLat");
        ELong = getIntent().getStringExtra("EndLong");

        tvPaymentShip.setText("Email: "+myEmail);


        if(Double.parseDouble(myWeight) <= 1 )
        {
            priceW = 3;
        }
        else if(Double.parseDouble(myWeight) > 1 && Double.parseDouble(myWeight) <= 5)
        {
            priceW = 5;
        }
        else if(Double.parseDouble(myWeight) > 5)
        {
            priceW = 7;
        }


        if(Double.parseDouble(myDist) > 0 && Double.parseDouble(myDist) <= 5)
        {
            priceD = 5;
        }
        else if(Double.parseDouble(myDist) > 5 && Double.parseDouble(myDist) <= 10)
        {
            priceD = 10;
        }
        else if(Double.parseDouble(myDist) > 10 && Double.parseDouble(myDist) <= 15)
        {
            priceD = 15;
        }
        else if(Double.parseDouble(myDist) > 15 && Double.parseDouble(myDist) <= 30)
        {
            priceD = 20;
        }


        if(myVehicle.equalsIgnoreCase("Motorcycle"))
        {
            priceV = 10;
        }
        else if(myVehicle.equalsIgnoreCase("Car"))
        {
            priceV = 15;
        }
        else if(myVehicle.equalsIgnoreCase("Van/Lorry"))
        {
            priceV = 20;
        }


        if(myFragile.equalsIgnoreCase("1"))
        {
            priceF = 4;
            frag = "Yes";
        }
        else
        {
            priceF = 0;
            frag = "No";
        }

        tvPService.setText("RM " +String.valueOf(priceV + priceF));
        tvDPriceKM.setText("RM " +String.valueOf(priceD));
        tvWPriceKG.setText("RM " +String.valueOf(priceW));
        tvIVechicle.setText(myVehicle);
        tvIItem.setText(myType);
        tvIFragile.setText(frag);
        tvDistanceKM.setText(myDist+" KM");
        tvweightKG.setText(myWeight+" KG");
        tvITotal.setText(String.valueOf(priceW + priceF + priceD + priceV));

        btnPaysubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentActivity.this, MapShippingActivity.class);
                intent.putExtra("MailingMapShipping", myEmail);
                intent.putExtra("KMDist",  tvDistanceKM.getText().toString());
                intent.putExtra("KGWeight",  tvweightKG.getText().toString());
                intent.putExtra("VehiclingShip",  tvIVechicle.getText().toString());
                intent.putExtra("TypeShip", tvIItem.getText().toString());
                intent.putExtra("Fragile", myFragile);
                intent.putExtra("PriceTotal",   tvITotal.getText().toString());
                intent.putExtra("StartLat", SLat);
                intent.putExtra("StartLong", SLong);
                intent.putExtra("EndLat", ELat);
                intent.putExtra("EndLong", ELong);
                startActivity(intent);
                finish();
            }
        });

        btnPayback.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentActivity.this, ShippingActivity.class);
                intent.putExtra("MailingShip", myEmail);
                startActivity(intent);
                finish();
            }
        });

        rbNormal.setText("NORMAL  (RM"+String.valueOf(priceW + priceF + priceD + priceV)+")");
        rbExpress.setText("EXPRESS  (RM"+String.valueOf(priceW + priceF + priceD + priceV)+" + 5)");
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.reg:
                if (checked)
                    total = priceW + priceF + priceD + priceV;
                break;
            case R.id.fast:
                if (checked)
                    total = priceW + priceF + priceD + priceV + 5;
                break;
        }
    }
}

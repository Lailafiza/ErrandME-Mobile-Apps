package com.example.ERRANDME.Config;

public class Config {
    public static final String PAYPAL_CLIENT_ID= "AflSyDCR_eNdNLSmApBal6mRa2MYXOLymzFI1ZlMTfXH5ClwhVeJNOIXomq624F5R95O7hWQr7wdP6ly";
}


package com.example.ERRANDME;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.XmlResourceParser;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class SignUpActivity extends AppCompatActivity {

    private EditText inputEmail, inputPassword, inputName, inputPhoneNum;
    private Button btnSignIn, btnSignUp;
    private ToggleButton btnRole;
    private CheckBox sp;
    private TextView clear;
    private String roleDecide;
    private ProgressBar progressBar;
    private FirebaseAuth auth;
    public static final String USER_ID = "com.example.ERRANDME.UserId";
    public static final String USER_EMAIL = "com.example.ERRANDME.UserEmail";
    public static final String USER_PASSWORD = "com.example.ERRANDME.UserPassword";
    public static final String USER_NAME = "com.example.ERRANDME.UserName";
    public static final String USER_PHONENUM = "com.example.ERRANDME.UserPhoneNum";
    public static final String USER_ROLE = "com.example.ERRANDME.UserRole";
    public static final String USER_CREATED = "com.example.ERRANDME.UserCreated";
    public static final String USER_MODIFIED = "com.example.ERRANDME.UserModified";

    ListView listViewUsers;
    List<User> users;
    DatabaseReference databaseUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        //Get Firebase auth instance
        auth = FirebaseAuth.getInstance();
        databaseUsers = FirebaseDatabase.getInstance().getReference("users");

        btnSignIn = findViewById(R.id.sign_in_button);
        btnSignUp = findViewById(R.id.sign_up_button);
        btnRole = findViewById(R.id.role);
        inputEmail = findViewById(R.id.email);
        inputPassword = findViewById(R.id.password);
        inputName = findViewById(R.id.name);
        inputPhoneNum = findViewById(R.id.phoneNum);
        sp = findViewById(R.id.showhidePassword);
        clear = findViewById(R.id.clearText);
        progressBar = findViewById(R.id.progressBar);

        users = new ArrayList<>();

        btnRole.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                     roleDecide = "1";
                } else {
                     roleDecide = "2";
                }
            }
        });

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String email = inputEmail.getText().toString().trim();
                String password = inputPassword.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (password.length() < 6) {
                    Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
                    return;
                }


                if (TextUtils.isEmpty(inputName.getText().toString().trim()) || TextUtils.isEmpty(inputName.getText().toString().trim())) {
                    Toast.makeText(getApplicationContext(), "Please complete your registration", Toast.LENGTH_SHORT).show();
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);
                //create user
                auth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                Toast.makeText(SignUpActivity.this, "createUserWithEmail:onComplete:" + task.isSuccessful(), Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                                // If sign in fails, display a message to the user. If sign in succeeds
                                // the auth state listener will be notified and logic to handle the
                                // signed in user can be handled in the listener.
                                if (!task.isSuccessful()) {
                                    Toast.makeText(SignUpActivity.this, "Authentication failed." + task.getException(),
                                            Toast.LENGTH_SHORT).show();
                                } else {
                                    addUser();

                                }
                            }
                        });
            }

        });

        sp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton button,
                                                 boolean isChecked) {
                        if (isChecked) {

                            sp.setText("Hide Password");
                            inputPassword.setInputType(InputType.TYPE_CLASS_TEXT);
                            inputPassword.setTransformationMethod(HideReturnsTransformationMethod
                                    .getInstance());

                        } else {

                            sp.setText("Show Password");
                            inputPassword.setInputType(InputType.TYPE_CLASS_TEXT
                                    | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                            inputPassword.setTransformationMethod(PasswordTransformationMethod
                                    .getInstance());
                        }
                    }
                });

        @SuppressLint("ResourceType") XmlResourceParser xrp = getResources().getXml(R.drawable.text_selector);
        try {
            ColorStateList csl = ColorStateList.createFromXml(getResources(), xrp);
            sp.setTextColor(csl);
        } catch (Exception e) {
        }

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inputEmail.setText("");
                inputPassword.setText("");
                inputName.setText("");
                inputPhoneNum.setText("");
            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        progressBar.setVisibility((View.GONE));
    }

    private void addUser() {
        //getting the values to save

        String email = inputEmail.getText().toString().trim();
        String password = inputPassword.getText().toString().trim();
        String name = inputName.getText().toString().trim();
        String phoneNum = inputPhoneNum.getText().toString().trim();

        if (roleDecide == null)
        {
            roleDecide = "1";
        }

        String role = roleDecide;

        //getting a unique id using push().getKey() method
        //it will create a unique id and we will use it as the Primary Key for our user
        String id = databaseUsers.push().getKey();

        //creating an user Object
        User user = new User(id, email, password, name, phoneNum, role);

        //Saving the user
        databaseUsers.child(id).setValue(user);

        Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
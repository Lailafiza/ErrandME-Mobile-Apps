package com.example.ERRANDME;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Shipping {

    private String shippingId;
    private String shippingStartedLat;
    private String shippingStartedLong;
    private String shippingDestinationLat;
    private String shippingDestinationLong;
    private String shippingType;
    private String shippingWeight;
    private String shippingFragile;
    private String shippingVehicle;
    private String shippingIPrice;
    private String shippingPId;

    public Shipping() {

    }

    public Shipping (String shippingId, String shippingStartedLat, String shippingStartedLong,
                     String shippingDestinationLat, String shippingDestinationLong,
                     String shippingType, String shippingWeight, String shippingFragile,
                     String shippingVehicle, String shippingIPrice, String shoppingPId) {
        this.shippingId = shippingId;
        this.shippingStartedLat = shippingStartedLat;
        this.shippingStartedLong = shippingStartedLong;
        this.shippingDestinationLat = shippingDestinationLat;
        this.shippingDestinationLong = shippingDestinationLong;
        this.shippingType = shippingType;
        this.shippingWeight =  shippingWeight;
        this.shippingFragile = shippingFragile;
        this.shippingVehicle = shippingVehicle;
        this.shippingIPrice = shippingIPrice;
        this.shippingPId = shoppingPId;
    }

    public String getShippingId(){
        return shippingId;
    }

    public String getShippingStartedLat(){
        return shippingStartedLat;
    }

    public String getShippingStartedLong(){
        return shippingStartedLong;
    }

    public String getShippingDestinationLat(){
        return shippingDestinationLat;
    }

    public String getShippingDestinationLong(){
        return shippingDestinationLong;
    }

    public String getShippingType(){
        return shippingType;
    }

    public String getShippingWeight(){
        return shippingWeight;
    }

    public String getShippingFragile(){
        return shippingFragile;
    }

    public String getShippingVehicle(){
        return shippingVehicle;
    }

    public String getShippingIPrice(){
        return shippingIPrice;
    }

    public String getShippingPId(){
        return shippingPId;
    }
}
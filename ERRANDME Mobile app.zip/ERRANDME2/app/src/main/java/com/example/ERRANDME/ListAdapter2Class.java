package com.example.ERRANDME;

import android.content.Context;
import java.util.List;
import android.app.Activity;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ListAdapter2Class extends BaseAdapter {

    Context context;
    List<String> valueList1;
    List<String> valueList2;
    List<String> valueList3;
    List<String> valueList4;


    public ListAdapter2Class(List<String> listValue1, List<String> listValue2,
                             List<String> listValue3, List<String> listValue4, Context context)
    {
        this.context = context;
        this.valueList1 = listValue1;
        this.valueList2 = listValue2;
        this.valueList3 = listValue3;
        this.valueList4 = listValue4;
    }

    @Override
    public int getCount()
    {
        return this.valueList1.size();
    }

    @Override
    public Object getItem(int position)
    {
        return this.valueList1.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewItem2 viewItem = null;

        if(convertView == null)
        {
            viewItem = new ViewItem2();

            LayoutInflater layoutInfiater = (LayoutInflater)this.context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

            convertView = layoutInfiater.inflate(R.layout.listview_history, null);

            viewItem.HName = (TextView)convertView.findViewById(R.id.historyName);
            viewItem.HContact = (TextView)convertView.findViewById(R.id.historyContact);
            viewItem.HService = (TextView)convertView.findViewById(R.id.historyService);
            viewItem.HPrice = (TextView)convertView.findViewById(R.id.historyPrice);

            convertView.setTag(viewItem);
        }
        else
        {
            viewItem = (ViewItem2) convertView.getTag();
        }

        viewItem.HName.setText(valueList1.get(position).toString());
        viewItem.HContact.setText(valueList2.get(position).toString());
        viewItem.HService.setText(valueList3.get(position).toString());
        viewItem.HPrice.setText(valueList4.get(position).toString());

        return convertView;
    }
}

class ViewItem2
{
    TextView HName;
    TextView HContact;
    TextView HService;
    TextView HPrice;
}
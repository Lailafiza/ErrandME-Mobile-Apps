package com.example.ERRANDME;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Shopping {

    private String shoppingId;
    private String shoppingDesc;
    private String shoppingVehicle;
    private String shoppingMPrice;
    private String shoppingPId;

    public Shopping() {

    }

    public Shopping (String shoppingId, String shoppingDesc, String shoppingVehicle,
                     String shoppingMPrice, String shoppingPId) {
        this.shoppingId = shoppingId;
        this.shoppingDesc = shoppingDesc;
        this.shoppingVehicle = shoppingVehicle;
        this.shoppingMPrice = shoppingMPrice;
        this.shoppingPId = shoppingPId;
    }

    public String getShoppingId(){
        return shoppingId;
    }

    public String getshoppingDesc(){
        return shoppingDesc;
    }

    public String getShoppingVehicle(){
        return shoppingVehicle;
    }

    public String getShoppingMPrice(){
        return shoppingMPrice;
    }

    public String getShoppingPId(){
        return shoppingPId;
    }
}
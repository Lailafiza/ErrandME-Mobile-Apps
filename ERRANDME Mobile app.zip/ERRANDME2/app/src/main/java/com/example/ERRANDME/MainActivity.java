package com.example.ERRANDME;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private Button signOut,Profile, Service, Location, Status, History;
    private TextView Welcome;
    String myEmail, role, id;
    int count = 0;
    private FirebaseAuth.AuthStateListener authListener;
    private FirebaseAuth auth;
    List<String> idList = new ArrayList<>();
    List<String> serviceList = new ArrayList<>();
    List<String> statusList = new ArrayList<>();
    List<String> theyList = new ArrayList<>();
    List<String> nameList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();

        //get current user
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        myEmail = user.getEmail();

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = database.getReference("users");
        final DatabaseReference table_progress = database.getReference("progresss");
        final DatabaseReference table_notification = database.getReference("notifications");

        table_user.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    String email = ds.child("userEmail").getValue().toString();

                    if (myEmail.equalsIgnoreCase(email))
                    {
                        role = ds.child("userRole").getValue().toString();
                        id = ds.child("userId").getValue().toString();
                        Welcome.setText("Welcome " + myEmail);

                        if(role.equalsIgnoreCase("2"))
                        {
                         Service.setVisibility(View.GONE);
                         Location.setVisibility(View.VISIBLE);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        authListener = new FirebaseAuth.AuthStateListener(){

            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user == null) {
                    // user auth state is changed - user is null
                    // launch login activity
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    finish();
                }
            }
        };

        table_progress.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    if(role.equalsIgnoreCase("1"))
                    {
                        if(id.equalsIgnoreCase(ds.child("progCustID").getValue().toString()))
                        {
                            if(ds.child("progStatus").getValue().toString().equalsIgnoreCase("Ongoing"))
                            {
                                idList.add(ds.child("progID").getValue().toString());
                                serviceList.add(ds.child("progService").getValue().toString());
                                statusList.add(ds.child("progStatus").getValue().toString());
                                theyList.add(ds.child("progDispID").getValue().toString());
                            }
                        }
                    }
                    else if(role.equalsIgnoreCase("2"))
                    {
                        if(id.equalsIgnoreCase(ds.child("progDispID").getValue().toString()))
                        {
                            if(ds.child("progStatus").getValue().toString().equalsIgnoreCase("Pending"))
                            {
                                idList.add(ds.child("progID").getValue().toString());
                                serviceList.add(ds.child("progService").getValue().toString());
                                statusList.add(ds.child("progStatus").getValue().toString());
                                theyList.add(ds.child("progCustID").getValue().toString());
                            }
                        }
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        table_user.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    for (int i = 0; i < theyList.size(); i++)
                    {
                        if(ds.child("userId").getValue().toString().equalsIgnoreCase(theyList.get(i).toString()))
                        {
                            nameList.add(ds.child("userName").getValue().toString());
                        }
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        table_notification.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    if(role.equalsIgnoreCase("1"))
                    {
                        if(idList.size() != 0)
                        {
                            for (int i = 0; i < idList.size(); i++)
                            {
                                if(ds.child("notiProgId").getValue().toString().equalsIgnoreCase(idList.get(i).toString()))
                                {
                                    if(ds.child("notiCount").getValue().toString().equalsIgnoreCase("2") && statusList.get(i).toString().equalsIgnoreCase("Ongoing"))
                                    {
                                        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                                        String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "My Notifications", NotificationManager.IMPORTANCE_HIGH);

                                            // Configure the notification channel.
                                            notificationChannel.setDescription("Channel description");
                                            notificationChannel.enableLights(true);
                                            notificationChannel.setLightColor(Color.RED);
                                            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
                                            notificationChannel.enableVibration(true);
                                            notificationManager.createNotificationChannel(notificationChannel);
                                        }


                                        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(MainActivity.this, NOTIFICATION_CHANNEL_ID);

                                        notificationBuilder.setAutoCancel(true)
                                                .setDefaults(Notification.DEFAULT_ALL)
                                                .setWhen(System.currentTimeMillis())
                                                .setSmallIcon(R.drawable.ic_shuttle)
                                                .setTicker("Hearty365")
                                                .setPriority(Notification.PRIORITY_MAX)
                                                .setContentTitle("My Errand ("+serviceList.get(i).toString()+")")
                                                .setContentText(Html.fromHtml("Dear Customer, your errand <b>("+idList.get(i).toString()+")</b> has been accepted by <b>"
                                                        +nameList.get(i).toString()+"</b>."));

                                        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle()
                                                .bigText(Html.fromHtml("Dear Customer, your errand <b>("+idList.get(i).toString()+")</b> has been accepted by <b>"
                                                        +nameList.get(i).toString()+"</b>."))
                                                .setBigContentTitle("My Errand ("+serviceList.get(i).toString()+")");

                                        notificationBuilder.setStyle(bigTextStyle);
                                        notificationBuilder.setPriority(NotificationCompat.PRIORITY_MAX);

                                        notificationManager.notify(/*notification id*/1, notificationBuilder.build());

                                        DatabaseReference dR = FirebaseDatabase.getInstance().getReference("notifications").child(ds.child("notiID").getValue().toString());
                                        com.example.ERRANDME.Notification notification = new com.example.ERRANDME.Notification(ds.child("notiID").getValue().toString(), "3", idList.get(i).toString());
                                        dR.setValue(notification);
                                    }
                                }
                            }
                        }
                    }
                    else if(role.equalsIgnoreCase("2"))
                    {
                        if(idList.size() != 0)
                        {
                            for (int i = 0; i < idList.size(); i++)
                            {
                                if(ds.child("notiProgId").getValue().toString().equalsIgnoreCase(idList.get(i).toString()))
                                {
                                    if(ds.child("notiCount").getValue().toString().equalsIgnoreCase("1") && statusList.get(i).toString().equalsIgnoreCase("Pending"))
                                    {
                                        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                                        String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "My Notifications", NotificationManager.IMPORTANCE_HIGH);

                                            // Configure the notification channel.
                                            notificationChannel.setDescription("Channel description");
                                            notificationChannel.enableLights(true);
                                            notificationChannel.setLightColor(Color.RED);
                                            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
                                            notificationChannel.enableVibration(true);
                                            notificationManager.createNotificationChannel(notificationChannel);
                                        }


                                        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(MainActivity.this, NOTIFICATION_CHANNEL_ID);

                                        notificationBuilder.setAutoCancel(true)
                                                .setDefaults(Notification.DEFAULT_ALL)
                                                .setWhen(System.currentTimeMillis())
                                                .setSmallIcon(R.drawable.ic_shuttle)
                                                .setTicker("Hearty365")
                                                //     .setPriority(Notification.PRIORITY_MAX)
                                                .setContentTitle("Errand To Do ("+serviceList.get(i).toString()+")")
                                                .setContentText(Html.fromHtml("There is new errand request from <b>"+nameList.get(i).toString()+"</b>, <b>("+idList.get(i).toString()+")</b>."));

                                        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle()
                                                .bigText(Html.fromHtml("There is new errand request from <b>"+nameList.get(i).toString()+"</b>, <b>("+idList.get(i).toString()+")</b>."))
                                                .setBigContentTitle("Errand To Do ("+serviceList.get(i).toString()+")");

                                        notificationBuilder.setStyle(bigTextStyle);
                                        notificationBuilder.setPriority(NotificationCompat.PRIORITY_MAX);

                                        notificationManager.notify(/*notification id*/1, notificationBuilder.build());

                                        DatabaseReference dR = FirebaseDatabase.getInstance().getReference("notifications").child(ds.child("notiID").getValue().toString());
                                        com.example.ERRANDME.Notification notification = new com.example.ERRANDME.Notification(ds.child("notiID").getValue().toString(), "2", idList.get(i).toString());
                                        dR.setValue(notification);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        signOut =  findViewById(R.id.sign_out);
        Welcome =  findViewById(R.id.welcome);
        Profile =  findViewById(R.id.profile);
        Service =  findViewById(R.id.service);
        Location =  findViewById(R.id.location);
        Status =  findViewById(R.id.status);
        History =  findViewById(R.id.history);

        Profile.setOnClickListener(new View.OnClickListener() {

            //for passing data from one act to another act
            @Override
            public void onClick(View v) {
                Intent intentProfile = new Intent(MainActivity.this, UserProfileActivity.class);
                intentProfile.putExtra("Mailing", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        Service.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intentProfile = new Intent(MainActivity.this, ServiceActivity.class);
                intentProfile.putExtra("MailingService", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        Location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentProfile = new Intent(MainActivity.this, LocationActivity.class);
                intentProfile.putExtra("MailingLocation", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        Status.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intentProfile = new Intent(MainActivity.this, StatusActivity.class);
                intentProfile.putExtra("MailingStatus", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        History.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
                intent.putExtra("MailingHistory", myEmail);
                startActivity(intent);
                finish();
            }
        });

        signOut.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                signOut();
            }
        });
    }

    //sign out method
    public void signOut() {
        auth.signOut();
    }
    @Override
    public void onStart() {
        super.onStart();
        auth.addAuthStateListener(authListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (authListener != null) {
            auth.removeAuthStateListener(authListener);
        }

    }
}

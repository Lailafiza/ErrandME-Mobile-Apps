package com.example.ERRANDME;

import android.content.Context;
import java.util.List;
import android.app.Activity;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ListAdapterClass extends BaseAdapter {

    Context context;
    List<String> valueList1;
    List<String> valueList2;
    List<String> valueList3;

    public ListAdapterClass(List<String> listValue1, List<String> listValue2, List<String> listValue3, Context context)
    {
        this.context = context;
        this.valueList1 = listValue1;
        this.valueList2 = listValue2;
        this.valueList3 = listValue3;
    }

    @Override
    public int getCount()
    {
        return this.valueList1.size();
    }

    @Override
    public Object getItem(int position)
    {
        return this.valueList1.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewItem viewItem = null;

        if(convertView == null)
        {
            viewItem = new ViewItem();

            LayoutInflater layoutInfiater = (LayoutInflater)this.context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

            convertView = layoutInfiater.inflate(R.layout.listview_status, null);

            viewItem.SName = convertView.findViewById(R.id.statusName); //refer to layout.xml
            viewItem.SService = convertView.findViewById(R.id.statusService); //refer to layout.xml
            viewItem.SStatus = convertView.findViewById(R.id.statusStatus);  //refer to layout.xml

            convertView.setTag(viewItem);
        }
        else
        {
            viewItem = (ViewItem) convertView.getTag();
        }

        viewItem.SName.setText(valueList1.get(position).toString()); // untuk displaykan data
        viewItem.SService.setText(valueList2.get(position).toString()); //
        viewItem.SStatus.setText(valueList3.get(position).toString()); //untu

        return convertView;
    }
}

//untuk view list kt dalam textview refer to layout.xml
class ViewItem
{
    TextView SName;
    TextView SService;
    TextView SStatus;
}
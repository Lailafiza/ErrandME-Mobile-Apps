package com.example.ERRANDME;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import org.json.JSONException;
import org.json.JSONObject;

public class PaymentDetails extends AppCompatActivity {
    TextView txtId,txtAmount,txtStatus, txtEmail, txtService;
    Button btnPaid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_details);

        txtId = findViewById(R.id.txtId);
        txtAmount = findViewById(R.id.txtAmount);
        txtStatus = findViewById(R.id.txtStatus);
        txtEmail = findViewById(R.id.txtEmail);
        txtService = findViewById(R.id.txtService);
        btnPaid = findViewById(R.id.btnPaid);

        Intent intent = getIntent();

        try {
            JSONObject jsonObject = new JSONObject(intent.getStringExtra("Payment Details"));
            showDetails(jsonObject.getJSONObject("response"),intent.getStringExtra("Amount")
                    ,intent.getStringExtra("ProgId")
                    ,intent.getStringExtra("MyId")
                    ,intent.getStringExtra("DispId")
                    ,intent.getStringExtra("MyLat")
                    ,intent.getStringExtra("MyLong")
                    ,intent.getStringExtra("MyRole")
                    ,intent.getStringExtra("MyEmail")
                    ,intent.getStringExtra("MyService"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void showDetails(JSONObject response, String paymentAmount, String progId, String myId, String DispId, String myLat,
                             String myLong, String myRole, String myEmail, String myService) {
        try {
            txtId.setText(response.getString("id"));
            txtStatus.setText(response.getString("state"));
            txtAmount.setText("RM"+paymentAmount);
            txtEmail.setText(myEmail);
            txtService.setText(myService);

            btnPaid.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(progId);
                    com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(progId, myService, "PaymentPaypal",
                            paymentAmount, myLat, myLong, myId, DispId);
                    dR.setValue(progress);

                    if(myService.equalsIgnoreCase("FastFood") || myService.equalsIgnoreCase("Shopping"))
                    {
                        Toast.makeText(getApplicationContext(), "Successful pay via Paypal", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(PaymentDetails.this, FoodShopActivity.class);
                        intent.putExtra("ProgId", progId);
                        intent.putExtra("MyId", myId);
                        intent.putExtra("MyRole", myRole);
                        intent.putExtra("MyEmail", myEmail);
                        intent.putExtra("MyService", myService);
                        startActivity(intent);
                        finish();
                    }
                    else if (myService.equalsIgnoreCase("Shipping") )
                    {
                        Toast.makeText(getApplicationContext(), "Successful pay via Paypal", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(PaymentDetails.this, ShipActivity.class);
                        intent.putExtra("ProgId", progId);
                        intent.putExtra("MyId", myId);
                        intent.putExtra("MyRole", myRole);
                        intent.putExtra("MyEmail", myEmail);
                        intent.putExtra("MyService", myService);
                        startActivity(intent);
                        finish();
                    }
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
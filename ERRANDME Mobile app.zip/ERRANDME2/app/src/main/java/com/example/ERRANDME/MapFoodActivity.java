package com.example.ERRANDME;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MapFoodActivity extends FragmentActivity implements OnMapReadyCallback,
        LocationListener, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {

    private Button back, refresh, submit;
    private TextView name, contact, vec, type, plate, textvec;
    String myEmail, myOrder, myBrand, myVehicle, myPrice, dispId, dVec, dType, dPlate, dName,
            dContact, custId, progId, foodId, locId, notiId;
    private GoogleMap mMap;
    Location mLastLocation;
    Marker mCurrLocationMarker;
    GoogleApiClient mGoogleApiClient;
    LocationRequest mLocationRequest;
    private LocationManager locationManager;
    Double LatStart, LongStart, LatEnd, LongEnd, distance, minDistance = 10000.00, LatDest, LongDest;
    List<String> latList = new ArrayList<>();
    List<String> longList = new ArrayList<>();
    List<String> dispList = new ArrayList<>();
    List<String> vecList = new ArrayList<>();
    List<String> typeList = new ArrayList<>();
    List<String> plateList = new ArrayList<>();
    List<String> vuList = new ArrayList<>();
    List<String> nameList = new ArrayList<>();
    List<String> contactList = new ArrayList<>();
    List<String> idList = new ArrayList<>();
    List<String> availableList = new ArrayList<>();
    List<String> locList = new ArrayList<>();
    List<String> emailList = new ArrayList<>();
    DecimalFormat newFormat = new DecimalFormat("#####0.00");
    private int LOCATION_PERMISSION_CODE = 1;
    DatabaseReference databaseProgresss;
    DatabaseReference databaseFastFoods;
    DatabaseReference databaseNotifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_food);

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_CODE);
        }

        databaseProgresss = FirebaseDatabase.getInstance().getReference("progresss");
        databaseFastFoods = FirebaseDatabase.getInstance().getReference("fastfoods");
        databaseNotifications = FirebaseDatabase.getInstance().getReference("notifications");

        back = findViewById(R.id.btnMapFBack);
        refresh = findViewById(R.id.btnMapFRefresh);
        name = findViewById(R.id.DispName);
        contact = findViewById(R.id.DispPNum);
        plate = findViewById(R.id.VehiclePlateNo);
        type = findViewById(R.id.VehicleType);
        vec = findViewById(R.id.VehicleName);
        textvec = findViewById(R.id.tvMfood);
        submit = findViewById(R.id.btnMapFSubmit);

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_location = database.getReference("locations");
        final DatabaseReference table_vehicle = database.getReference("vehicles");
        final DatabaseReference table_user = database.getReference("users");

        table_location.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                latList.clear();
                longList.clear();
                availableList.clear();
                locList.clear();
                dispList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    latList.add(ds.child("locationLat").getValue().toString());
                    longList.add(ds.child("locationLong").getValue().toString());
                    availableList.add(ds.child("locationAvailable").getValue().toString());
                    locList.add(ds.child("locationID").getValue().toString());
                    dispList.add(ds.child("locationUserID").getValue().toString());
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        table_vehicle.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                vecList.clear();
                typeList.clear();
                plateList.clear();
                vuList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    vecList.add(ds.child("vehicleName").getValue().toString());
                    typeList.add(ds.child("vehicleType").getValue().toString());
                    plateList.add(ds.child("vehiclePNum").getValue().toString());
                    vuList.add(ds.child("vehicleUserId").getValue().toString());
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        table_user.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                nameList.clear();
                contactList.clear();
                idList.clear();
                emailList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    nameList.add(ds.child("userName").getValue().toString());
                    contactList.add(ds.child("userPhoneNum").getValue().toString());
                    idList.add(ds.child("userId").getValue().toString());
                    emailList.add(ds.child("userEmail").getValue().toString());
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map4);
        mapFragment.getMapAsync(MapFoodActivity.this);

        myEmail = getIntent().getStringExtra("MailingMapFood");
        myOrder = getIntent().getStringExtra("OrderingF");
        myBrand = getIntent().getStringExtra("BrandF");
        myVehicle = getIntent().getStringExtra("VehiclingF");
        myPrice = getIntent().getStringExtra("PricingF");

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentProfile = new Intent(MapFoodActivity.this, FoodActivity.class);
                intentProfile.putExtra("MailingFood", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentProfile = new Intent(MapFoodActivity.this, MapFoodActivity.class);
                intentProfile.putExtra("MailingMapFood", myEmail);
                intentProfile.putExtra("BrandF", myBrand);
                intentProfile.putExtra("OrderingF", myOrder);
                intentProfile.putExtra("VehiclingF", myVehicle);
                intentProfile.putExtra("PricingF", myPrice);
                startActivity(intentProfile);
                finish();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!String.valueOf(LatStart).isEmpty() && !String.valueOf(LongStart).isEmpty() && !myBrand.isEmpty() && !myOrder.isEmpty() && !myVehicle.isEmpty() && !myPrice.isEmpty())
                {
                    progId = databaseProgresss.push().getKey();
                    com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(progId, "FastFood",
                            "Pending", "0", String.valueOf(LatStart),
                            String.valueOf(LongStart), custId, dispId);
                    databaseProgresss.child(progId).setValue(progress);

                    foodId = databaseFastFoods.push().getKey();
                    com.example.ERRANDME.FastFood fastFood = new com.example.ERRANDME.FastFood(foodId, myBrand, myOrder, myVehicle, myPrice, progId);
                    databaseFastFoods.child(foodId).setValue(fastFood);

                    notiId = databaseNotifications.push().getKey();
                    com.example.ERRANDME.Notification notification = new com.example.ERRANDME.Notification(notiId, "1", progId);
                    databaseNotifications.child(notiId).setValue(notification);

                    DatabaseReference dR = FirebaseDatabase.getInstance().getReference("locations").child(locId);
                    com.example.ERRANDME.Location location = new com.example.ERRANDME.Location(locId, String.valueOf(LatDest), String.valueOf(LongDest),
                            "1", dispId);
                    dR.setValue(location);

                    Toast.makeText(getApplicationContext(), "Order been delivered", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MapFoodActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(MapFoodActivity.this, "Sorry, please refresh or reorder back!!!", Toast.LENGTH_LONG).show();
                }

            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        checkLocation();

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mMap.setMyLocationEnabled(true);
            }
        }
        else {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
        }

    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API).build();
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnected(Bundle bundle) {

        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onLocationChanged(Location location) {

        mMap.clear();
        mLastLocation = location;
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }

        LatStart = location.getLatitude();
        LongStart = location.getLongitude();
        LatLng latLng = new LatLng(LatStart, LongStart);

        if(dispList.size() != 0)
        {
            for (int i = 0; i < dispList.size(); i++) {
                if(availableList.get(i).toString().equalsIgnoreCase("2"))
                {
                    LatEnd = Double.parseDouble(latList.get(i).toString());
                    LongEnd = Double.parseDouble(longList.get(i).toString());

                    LatLng latLng2 = new LatLng(LatEnd, LongEnd);
                    distance = CalculationByDistance(latLng, latLng2);

                    if(distance < minDistance)
                    {
                        minDistance = distance;
                        dispId = dispList.get(i).toString();
                        locId = locList.get(i).toString();
                        LatDest = Double.parseDouble(latList.get(i).toString());
                        LongDest = Double.parseDouble(longList.get(i).toString());
                    }
                }
            }

            for (int i = 0; i < vuList.size(); i++) {
                if(dispId != null)
                {
                    if(dispId.equalsIgnoreCase(vuList.get(i).toString()))
                    {
                        dVec = vecList.get(i).toString();
                        dType = typeList.get(i).toString();
                        dPlate = plateList.get(i).toString();
                    }
                }
            }

            for (int i = 0; i < idList.size(); i++) {
                if(dispId != null)
                {
                    if(dispId.equalsIgnoreCase(idList.get(i).toString()))
                    {
                        dName = nameList.get(i).toString();
                        dContact = contactList.get(i).toString();
                    }
                }
            }

            for (int i = 0; i < emailList.size(); i++) {
                if(dispId != null)
                {
                    if(myEmail.equalsIgnoreCase(emailList.get(i).toString()))
                    {
                        custId = idList.get(i).toString();
                    }
                }
            }
        }

        if(dispId != null)
        {
            if(minDistance <= 10)
            {
                if(dVec != null)
                {
                    MarkerOptions marker = new MarkerOptions().position(new LatLng(LatDest, LongDest)).title(dName)
                            .snippet("Distance: " + minDistance + " KM")
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
                    mMap.addMarker(marker);

                    name.setText(dName);
                    contact.setText(dContact);
                    vec.setText(dVec);
                    type.setText(dType);
                    plate.setText(dPlate);
                }
                else
                {
                    name.setVisibility(View.GONE);
                    contact.setVisibility(View.GONE);
                    vec.setVisibility(View.GONE);
                    type.setVisibility(View.GONE);
                    plate.setVisibility(View.GONE);
                    textvec.setVisibility(View.GONE);
                    Toast.makeText(MapFoodActivity.this, "Sorry, service not within your area", Toast.LENGTH_LONG).show();
                }
            }
            else
            {
                name.setVisibility(View.GONE);
                contact.setVisibility(View.GONE);
                vec.setVisibility(View.GONE);
                type.setVisibility(View.GONE);
                plate.setVisibility(View.GONE);
                textvec.setVisibility(View.GONE);
                Toast.makeText(MapFoodActivity.this, "Sorry, service not within your area", Toast.LENGTH_LONG).show();
            }
        }
        else
        {
            name.setVisibility(View.GONE);
            contact.setVisibility(View.GONE);
            vec.setVisibility(View.GONE);
            type.setVisibility(View.GONE);
            plate.setVisibility(View.GONE);
            textvec.setVisibility(View.GONE);
            Toast.makeText(MapFoodActivity.this, "Sorry, service not within your area", Toast.LENGTH_LONG).show();
        }

        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("Your Location");
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
        mCurrLocationMarker = mMap.addMarker(markerOptions);

        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

        if (dispId != null)
        {
            if(minDistance <= 10)
            {
                if(dVec != null)
                {
                    mMap.animateCamera(CameraUpdateFactory.zoomTo(11));
                    Circle circle = mMap.addCircle(new CircleOptions()
                            .center(latLng)
                            .radius(10000)
                            .strokeColor(Color.argb(50, 113,204, 231))
                            .fillColor(Color.argb(50, 113,204, 231)));
                }
                else
                {
                    mMap.animateCamera(CameraUpdateFactory.zoomTo(12));
                }
            }
            else
            {
                mMap.animateCamera(CameraUpdateFactory.zoomTo(12));
            }
        }
        else
        {
            mMap.animateCamera(CameraUpdateFactory.zoomTo(12));
        }

        if (mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }

    private boolean checkLocation() {
        if(!isLocationEnabled())
            showAlert();
        return isLocationEnabled();
    }

    private void showAlert() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'. Please Enable Location to use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                });
        dialog.show();
    }

    private boolean isLocationEnabled() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    public double CalculationByDistance(LatLng StartP, LatLng EndP) {
        int Radius = 6371;
        double lat1 = StartP.latitude;
        double lat2 = EndP.latitude;
        double lon1 = StartP.longitude;
        double lon2 = EndP.longitude;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                * Math.sin(dLon / 2);
        double c = 2 * Math.asin(Math.sqrt(a));
        double valueResult = Radius * c;
        double km = valueResult / 1;
        double kmInDec = Double.valueOf(newFormat.format(km));

        return kmInDec;
    }
}

package com.example.ERRANDME;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class FoodActivity extends AppCompatActivity {


    private Button btnFsubmit, btnFback,btnFmenu, clear;
    private Spinner Fbrand, Fvehicle;
    private EditText etFdesc, etFprice;
    String myEmail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        etFdesc = findViewById(R.id.FDesc);
        etFprice = findViewById(R.id.FPrice);
        Fbrand = findViewById(R.id.sFBrand);
        Fvehicle = findViewById(R.id.sFVehicle);
        clear = findViewById(R.id.clearFText);
        btnFmenu = findViewById(R.id.btnFMenu);
        btnFsubmit = findViewById(R.id.btnFSubmit);
        btnFback = findViewById(R.id.btnFBack);

        myEmail = getIntent().getStringExtra("MailingFood");


        addItemsOnSpinner();
        addItemsOnSpinner2();

        Fbrand.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(String.valueOf(Fbrand.getSelectedItem()).equalsIgnoreCase("KFC"))
                {
                    btnFmenu.setVisibility(View.VISIBLE);
                    btnFmenu.setText("KFC Menu");
                }
                else if(String.valueOf(Fbrand.getSelectedItem()).equalsIgnoreCase("Mc Donald's"))
                {
                    btnFmenu.setVisibility(View.VISIBLE);
                    btnFmenu.setText("Mc Donald's Menu");
                }
                else if(String.valueOf(Fbrand.getSelectedItem()).equalsIgnoreCase("Domino's"))
                {
                    btnFmenu.setVisibility(View.VISIBLE);
                    btnFmenu.setText("Domino's Menu");
                }
                else if(String.valueOf(Fbrand.getSelectedItem()).equalsIgnoreCase("Pizza Hut"))
                {
                    btnFmenu.setVisibility(View.VISIBLE);
                    btnFmenu.setText("Pizza Hut Menu");
                }
            }

            public void onNothingSelected(AdapterView<?> parent) {}
        });

        btnFsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!myEmail.isEmpty() && !String.valueOf(Fbrand.getSelectedItem()).isEmpty() && !etFdesc.getText().toString().isEmpty() && !String.valueOf(Fvehicle.getSelectedItem()).isEmpty() && !etFprice.getText().toString().isEmpty())
                {
                    Intent intentProfile = new Intent(FoodActivity.this, MapFoodActivity.class);
                    intentProfile.putExtra("MailingMapFood", myEmail);
                    intentProfile.putExtra("BrandF", String.valueOf(Fbrand.getSelectedItem()));
                    intentProfile.putExtra("OrderingF", etFdesc.getText().toString());
                    intentProfile.putExtra("VehiclingF", String.valueOf(Fvehicle.getSelectedItem()));
                    intentProfile.putExtra("PricingF", etFprice.getText().toString());
                    startActivity(intentProfile);
                    finish();
                }
                else
                {
                    Toast.makeText(FoodActivity.this, "Please complete your order!!!", Toast.LENGTH_LONG).show();
                }
            }
        });


        btnFback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FoodActivity.this, ServiceActivity.class);
                intent.putExtra("MailingService", myEmail);
                startActivity(intent);
                finish();
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fbrand.setSelection(0);
                etFdesc.setText("");
                Fvehicle.setSelection(0);
                etFprice.setText("");
            }
        });

    }

    public void addItemsOnSpinner() {

        List<String> list = new ArrayList<String>();
        list.add("Motorcycle");
        list.add("Car");
        list.add("Lorry/Van");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Fvehicle.setAdapter(dataAdapter);
    }

    public void addItemsOnSpinner2() {

        List<String> list = new ArrayList<String>();
        list.add("KFC");
        list.add("Mc Donald's");
        list.add("Domino's");
        list.add("Pizza Hut");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Fbrand.setAdapter(dataAdapter);
    }

    public void goToLink (View view) {
        if(String.valueOf(Fbrand.getSelectedItem()).equalsIgnoreCase("KFC"))
        {
            goToUrl ( "https://www.menus.my/kfc-menu/");
        }
        else if(String.valueOf(Fbrand.getSelectedItem()).equalsIgnoreCase("Mc Donald's"))
        {
            goToUrl ( "https://www.menus.my/mcdonalds-menu/");
        }
        else if(String.valueOf(Fbrand.getSelectedItem()).equalsIgnoreCase("Domino's"))
        {
            goToUrl ( "https://www.menus.my/dominos-pizza-menu/");
        }
        else if(String.valueOf(Fbrand.getSelectedItem()).equalsIgnoreCase("Pizza Hut"))
        {
            goToUrl ( "https://www.menus.my/pizza-hut-menu/");
        }

    }

    private void goToUrl (String url) {
        Intent intent = new Intent(this, WebViewActivity.class);
        intent.putExtra("url", url);
        startActivity(intent);
    }
}


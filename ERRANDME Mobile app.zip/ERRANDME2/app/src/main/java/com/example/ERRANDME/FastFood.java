package com.example.ERRANDME;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class FastFood {

    private String ffoodId;
    private String ffoodBrand;
    private String ffoodDesc;
    private String ffoodVehicle;
    private String ffoodPrice;
    private String ffoodPId;

    public FastFood() {

    }

    public FastFood (String ffoodId, String ffoodBrand, String ffoodDesc, String ffoodVehicle,
                     String ffoodPrice, String ffoodPId) {
        this.ffoodId = ffoodId;
        this.ffoodBrand = ffoodBrand;
        this.ffoodDesc = ffoodDesc;
        this.ffoodVehicle = ffoodVehicle;
        this.ffoodPrice = ffoodPrice;
        this.ffoodPId = ffoodPId;
    }

    public String getFfoodId(){
        return ffoodId;
    }

    public String getFfoodBrand () {
        return ffoodBrand;
    }

    public String getFfoodDesc  () {
        return ffoodDesc ;
    }

    public String getFfoodVehicle () {
        return ffoodVehicle;
    }

    public String getFfoodPrice () {
        return ffoodPrice;
    }

    public String getFfoodPId () {
        return ffoodPId;
    }
}
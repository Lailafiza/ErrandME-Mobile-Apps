package com.example.ERRANDME;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.ERRANDME.Config.Config;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.paypal.android.sdk.payments.PayPalConfiguration;
import com.paypal.android.sdk.payments.PayPalPayment;
import com.paypal.android.sdk.payments.PayPalService;
import com.paypal.android.sdk.payments.PaymentActivity;
import com.paypal.android.sdk.payments.PaymentConfirmation;
import org.json.JSONException;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class FoodShopActivity extends FragmentActivity implements OnMapReadyCallback,
        LocationListener, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {

    private static final int PAYPAL_REQUEST_CODE = 7777;

    private static PayPalConfiguration config = new PayPalConfiguration()
            .environment(PayPalConfiguration.ENVIRONMENT_SANDBOX)
            .clientId(Config.PAYPAL_CLIENT_ID);

    String myEmail, myId, myRole, proId, myService, custId, dispId, status, dispName, dispContact, custName, custContact, vName, vPlate, vType, vNeed,
            desc, harga, jenama, myLat, myLong, myPrice, id, amount;
    private TextView name, vehicle, service, brand, initialprice, order, totalpayment, iprice;
    private ImageView pending, ongoing, dispatch, complete, payment;
    private View lprice, lbtn, lbrand, lvehicle, litem, lbtn2;
    private EditText totalprice;
    private ImageButton call, ws, btnSF;
    private Button cancel, accept, reject, update, success, back, paypal, cod;
    private GoogleMap mMap;
    private SupportMapFragment mapFragment;
    private Context mContext;
    private Activity mActivity;
    private static final int MY_PERMISSION_REQUEST_CODE = 123;
    private int LOCATION_PERMISSION_CODE = 1;
    Location mLastLocation;
    Marker mCurrLocationMarker;
    GoogleApiClient mGoogleApiClient;
    LocationRequest mLocationRequest;
    private LocationManager locationManager;
    DecimalFormat newFormat = new DecimalFormat("#####0.00");
    Double LatStart, LongStart, distance;

    @Override
    protected void onDestroy() {
        stopService(new Intent(this,PayPalService.class));
        super.onDestroy();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_shop);

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_CODE);
        }

        mContext = getApplicationContext();
        mActivity = FoodShopActivity.this;

        name = findViewById(R.id.info1SF);
        vehicle = findViewById(R.id.info2SF);
        call = findViewById(R.id.callSF);
        ws = findViewById(R.id.wsSF);
        service = findViewById(R.id.item1SF);
        brand = findViewById(R.id.item2SF);
        initialprice = findViewById(R.id.item3SF);
        order = findViewById(R.id.item4SF);
        pending = findViewById(R.id.status1SF);
        ongoing = findViewById(R.id.status2SF);
        dispatch = findViewById(R.id.status3SF);
        complete = findViewById(R.id.status4SF);
        lprice = findViewById(R.id.layoutPrice);
        totalprice = findViewById(R.id.priceSF);
        cancel = findViewById(R.id.cancelFS);
        accept = findViewById(R.id.acceptFS);
        reject = findViewById(R.id.rejectFS);
        update = findViewById(R.id.updateFS);
        success = findViewById(R.id.completeFS);
        back = findViewById(R.id.backFS);
        lbtn = findViewById(R.id.layoutFS);
        lbrand = findViewById(R.id.layoutBrand);
        lvehicle = findViewById(R.id.layoutVehicle);
        btnSF = findViewById(R.id.btnSF);
        litem = findViewById(R.id.layoutItem);
        totalpayment = findViewById(R.id.item5SF);
        iprice = findViewById(R.id.iprice);
        lbtn2 = findViewById(R.id.layoutFS2);
        paypal = findViewById(R.id.paypalFS);
        cod = findViewById(R.id.codFS);
        payment = findViewById(R.id.status5SF);

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = database.getReference("users");
        final DatabaseReference table_progress = database.getReference("progresss");
        final DatabaseReference table_fastfood = database.getReference("fastfoods");
        final DatabaseReference table_shopping = database.getReference("shoppings");
        final DatabaseReference table_vehicle = database.getReference("vehicles");

        proId = getIntent().getStringExtra("ProgId");
        myId = getIntent().getStringExtra("MyId");
        myRole = getIntent().getStringExtra("MyRole");
        myEmail = getIntent().getStringExtra("MyEmail");
        myService = getIntent().getStringExtra("MyService");

        table_progress.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    if (proId.equalsIgnoreCase(ds.child("progID").getValue().toString())) {
                        if (myRole.equalsIgnoreCase("1")) {
                            dispId = ds.child("progDispID").getValue().toString();
                            status = ds.child("progStatus").getValue().toString();
                            myLat = ds.child("progLat").getValue().toString();
                            myLong = ds.child("progLong").getValue().toString();
                            myPrice = ds.child("progTotPrice").getValue().toString();

                        } else if (myRole.equalsIgnoreCase("2")) {
                            custId = ds.child("progCustID").getValue().toString();
                            status = ds.child("progStatus").getValue().toString();
                            myLat = ds.child("progLat").getValue().toString();
                            myLong = ds.child("progLong").getValue().toString();
                            myPrice = ds.child("progTotPrice").getValue().toString();

                        }
                    }
                }
                if (status.equalsIgnoreCase("Pending")) {
                    ongoing.setVisibility(View.INVISIBLE);
                    dispatch.setVisibility(View.INVISIBLE);
                    payment.setVisibility(View.INVISIBLE);
                    complete.setVisibility(View.INVISIBLE);
                } else if (status.equalsIgnoreCase("Ongoing")) {
                    dispatch.setVisibility(View.INVISIBLE);
                    payment.setVisibility(View.INVISIBLE);
                    complete.setVisibility(View.INVISIBLE);
                } else if (status.equalsIgnoreCase("Dispatching")) {
                    payment.setVisibility(View.INVISIBLE);
                    complete.setVisibility(View.INVISIBLE);
                } else if (status.equalsIgnoreCase("PaymentCOD") || status.equalsIgnoreCase("PaymentPaypal")) {
                    complete.setVisibility(View.INVISIBLE);
                }

                if(myRole.equalsIgnoreCase("1"))
                {
                    if(status.equalsIgnoreCase("Pending"))
                    {
                        cancel.setVisibility(View.VISIBLE);
                    }
                    else if (status.equalsIgnoreCase("Dispatching"))
                    {
                        lbtn2.setVisibility(View.VISIBLE);
                    }
                    else if (status.equalsIgnoreCase("PaymentCOD") || status.equalsIgnoreCase("PaymentPaypal"))
                    {
                        success.setVisibility(View.VISIBLE);
                    }
                }
                else if (myRole.equalsIgnoreCase("2"))
                {
                    if(status.equalsIgnoreCase("Pending"))
                    {
                        lbtn.setVisibility(View.VISIBLE);
                    }
                    else if(status.equalsIgnoreCase("Ongoing"))
                    {
                        lprice.setVisibility(View.VISIBLE);
                        update.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        table_user.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    if (myRole.equalsIgnoreCase("1")) {
                        if (dispId.equalsIgnoreCase(ds.child("userId").getValue().toString())) {
                            dispName = ds.child("userName").getValue().toString();
                            dispContact = ds.child("userPhoneNum").getValue().toString();
                        }
                    } else if (myRole.equalsIgnoreCase("2")) {
                        if (custId.equalsIgnoreCase(ds.child("userId").getValue().toString())) {
                            custName = ds.child("userName").getValue().toString();
                            custContact = ds.child("userPhoneNum").getValue().toString();
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map7);

        table_vehicle.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    if (myRole.equalsIgnoreCase("1")) {
                        if (dispId.equalsIgnoreCase(ds.child("vehicleUserId").getValue().toString())) {
                            vName = ds.child("vehicleName").getValue().toString();
                            vPlate = ds.child("vehiclePNum").getValue().toString();
                            vType = ds.child("vehicleType").getValue().toString();
                        }
                    } else if (myRole.equalsIgnoreCase("2")) {
                        vNeed = "Dont";
                    }
                }
                if (myRole.equalsIgnoreCase("1")) {
                    name.setText(dispName + " (Disptacher)");
                    vehicle.setText(vType + "\n" + vName + " (" + vPlate + ")");
                    mapFragment.getView().setVisibility(View.GONE);
                } else if (myRole.equalsIgnoreCase("2")) {
                    name.setText(custName + " (Customer)");
                    lvehicle.setVisibility(View.GONE);
                    mapFragment.getMapAsync(FoodShopActivity.this);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        if (myService.equalsIgnoreCase("FastFood")) {
            table_fastfood.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        if (proId.equalsIgnoreCase(ds.child("ffoodPId").getValue().toString())) {
                            desc = ds.child("ffoodDesc").getValue().toString();
                            harga = ds.child("ffoodPrice").getValue().toString();
                            jenama = ds.child("ffoodBrand").getValue().toString();
                            id = ds.child("ffoodId").getValue().toString();
                        }
                    }
                    if(status.equalsIgnoreCase("Dispatching") || status.equalsIgnoreCase("PaymentCOD")
                            || status.equalsIgnoreCase("PaymentPaypal"))
                    {
                        litem.setVisibility(View.VISIBLE);
                        totalpayment.setText(myPrice);
                    }
                    service.setText(myService);
                    brand.setText(jenama);
                    initialprice.setText(harga);
                    order.setText(desc);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        } else if (myService.equalsIgnoreCase("Shopping")) {
            table_shopping.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        if (proId.equalsIgnoreCase(ds.child("shoppingPId").getValue().toString())) {
                            desc = ds.child("shoppingDesc").getValue().toString();
                            harga = ds.child("shoppingMPrice").getValue().toString();
                            id = ds.child("shoppingId").getValue().toString();
                        }
                    }
                    if(status.equalsIgnoreCase("Dispatching") || status.equalsIgnoreCase("PaymentCOD")
                            || status.equalsIgnoreCase("PaymentPaypal"))
                    {
                        litem.setVisibility(View.VISIBLE);
                        totalpayment.setText(myPrice);
                    }
                    service.setText(myService);
                    lbrand.setVisibility(View.GONE);
                    iprice.setText("Max Price");
                    initialprice.setText(harga);
                    order.setText(desc);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }

        Intent intenting = new Intent(this,PayPalService.class);
        intenting.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION,config);
        startService(intenting);

        btnSF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showDialog(FoodShopActivity.this, desc);
            }
        });

        ws.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (myRole.equalsIgnoreCase("1")) {
                    String url = "https://api.whatsapp.com/send?phone=" + "+6"+dispContact;
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                } else if (myRole.equalsIgnoreCase("2")) {
                    String url = "https://api.whatsapp.com/send?phone=" + "+6"+custContact;
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
            }
        });

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkPermission();
                } else {
                    CallContact();
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentProfile = new Intent(FoodShopActivity.this, StatusActivity.class);
                intentProfile.putExtra("MailingStatus", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                dR.removeValue();

                if(myService.equalsIgnoreCase("FastFood"))
                {
                    DatabaseReference dR2 = FirebaseDatabase.getInstance().getReference("fastfoods").child(id);
                    dR2.removeValue();
                }
                else if (myService.equalsIgnoreCase("Shopping"))
                {
                    DatabaseReference dR2 = FirebaseDatabase.getInstance().getReference("shoppings").child(id);
                    dR2.removeValue();
                }

                Toast.makeText(getApplicationContext(), "Canceling Order", Toast.LENGTH_LONG).show();
                Intent intentProfile = new Intent(FoodShopActivity.this, StatusActivity.class);
                intentProfile.putExtra("MailingStatus", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(proId, myService, "Ongoing", myPrice,
                        myLat, myLong, custId, myId);
                dR.setValue(progress);

                Toast.makeText(getApplicationContext(), "Accepting Order", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(FoodShopActivity.this, FoodShopActivity.class);
                intent.putExtra("ProgId", proId);
                intent.putExtra("MyId", myId);
                intent.putExtra("MyRole", myRole);
                intent.putExtra("MyEmail", myEmail);
                intent.putExtra("MyService", myService);
                startActivity(intent);
                finish();
            }
        });

        cod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(proId, myService, "PaymentCOD", myPrice,
                        myLat, myLong, myId, dispId);
                dR.setValue(progress);

                Toast.makeText(getApplicationContext(), "Pay when dispatcher arrived", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(FoodShopActivity.this, FoodShopActivity.class);
                intent.putExtra("ProgId", proId);
                intent.putExtra("MyId", myId);
                intent.putExtra("MyRole", myRole);
                intent.putExtra("MyEmail", myEmail);
                intent.putExtra("MyService", myService);
                startActivity(intent);
                finish();
            }
        });

        paypal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                processPayment();
            }
        });

        reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                dR.removeValue();

                if(myService.equalsIgnoreCase("FastFood"))
                {
                    DatabaseReference dR2 = FirebaseDatabase.getInstance().getReference("fastfoods").child(id);
                    dR2.removeValue();
                }
                else if (myService.equalsIgnoreCase("Shopping"))
                {
                    DatabaseReference dR2 = FirebaseDatabase.getInstance().getReference("shoppings").child(id);
                    dR2.removeValue();
                }

                Toast.makeText(getApplicationContext(), "Rejecting Order", Toast.LENGTH_LONG).show();
                Intent intentProfile = new Intent(FoodShopActivity.this, StatusActivity.class);
                intentProfile.putExtra("MailingStatus", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!totalprice.getText().toString().isEmpty())
                {
                    DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                    com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(proId, myService, "Dispatching",
                            totalprice.getText().toString(), myLat, myLong, custId, myId);
                    dR.setValue(progress);

                    Toast.makeText(getApplicationContext(), "Update Order", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(FoodShopActivity.this, FoodShopActivity.class);
                    intent.putExtra("ProgId", proId);
                    intent.putExtra("MyId", myId);
                    intent.putExtra("MyRole", myRole);
                    intent.putExtra("MyEmail", myEmail);
                    intent.putExtra("MyService", myService);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(FoodShopActivity.this, "Please insert updated price!!!", Toast.LENGTH_LONG).show();
                }
            }
        });

        success.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(proId, myService, "Complete",
                        myPrice, myLat, myLong, myId, dispId);
                dR.setValue(progress);

                Toast.makeText(getApplicationContext(), "Mission Success", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(FoodShopActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    protected void CallContact() {
        Intent intent = new Intent(Intent.ACTION_CALL);
        // Send phone number to intent as data

        if(myRole.equalsIgnoreCase("1"))
        {
            intent.setData(Uri.parse("tel:" + "+6"+dispContact));
        }
        else if (myRole.equalsIgnoreCase("2"))
        {
            intent.setData(Uri.parse("tel:" + "+6"+custContact));
        }

        // Start the dialer app activity to make phone call
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(intent);

    }

    protected void checkPermission(){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
            if(checkSelfPermission(Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
                if(shouldShowRequestPermissionRationale(Manifest.permission.CALL_PHONE)){
                    // show an alert dialog
                    AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
                    builder.setMessage("Call Phone permission is required.");
                    builder.setTitle("Please grant permission");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ActivityCompat.requestPermissions(
                                    mActivity,
                                    new String[]{Manifest.permission.CALL_PHONE},
                                    MY_PERMISSION_REQUEST_CODE
                            );
                        }
                    });
                    builder.setNeutralButton("Cancel",null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }else {
                    // Request permission
                    ActivityCompat.requestPermissions(
                            mActivity,
                            new String[]{Manifest.permission.CALL_PHONE},
                            MY_PERMISSION_REQUEST_CODE
                    );
                }
            }else {
                // Permission already granted
                CallContact();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        switch(requestCode){
            case MY_PERMISSION_REQUEST_CODE:{
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    // Permission granted
                    CallContact();
                }else {
                    // Permission denied
                }
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        checkLocation();

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mMap.setMyLocationEnabled(true);
            }
        }
        else {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
        }

    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API).build();
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnected(Bundle bundle) {

        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onLocationChanged(Location location) {

        mMap.clear();
        mLastLocation = location;
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }

        LatStart = location.getLatitude();
        LongStart = location.getLongitude();
        LatLng latLng = new LatLng(LatStart, LongStart);
        LatLng latLng2 = new LatLng(Double.valueOf(myLat), Double.valueOf(myLong));
        distance = CalculationByDistance(latLng, latLng2);
        MarkerOptions marker = new MarkerOptions().position(new LatLng(Double.valueOf(myLat), Double.valueOf(myLong))).title(custName)
                .snippet("Distance: " + distance + " KM")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        mMap.addMarker(marker);

        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("Your Location");
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
        mCurrLocationMarker = mMap.addMarker(markerOptions);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

        mMap.animateCamera(CameraUpdateFactory.zoomTo(12));
        Circle circle = mMap.addCircle(new CircleOptions()
                .center(latLng)
                .radius(10000)
                .strokeColor(Color.argb(0, 113,204, 231))
                .fillColor(Color.argb(0, 113,204, 231)));

        if (mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }

    private boolean checkLocation() {
        if(!isLocationEnabled())
            showAlert();
        return isLocationEnabled();
    }

    private void showAlert() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'. Please Enable Location to use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                });
        dialog.show();
    }

    private boolean isLocationEnabled() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    public double CalculationByDistance(LatLng StartP, LatLng EndP) {
        int Radius = 6371;
        double lat1 = StartP.latitude;
        double lat2 = EndP.latitude;
        double lon1 = StartP.longitude;
        double lon2 = EndP.longitude;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                * Math.sin(dLon / 2);
        double c = 2 * Math.asin(Math.sqrt(a));
        double valueResult = Radius * c;
        double km = valueResult / 1;
        double kmInDec = Double.valueOf(newFormat.format(km));

        return kmInDec;
    }

    private void showDialog(Context c, final String myOrder) {

        AlertDialog dialog = new AlertDialog.Builder(c)
                .setTitle("Order List")
                .setMessage(Html.fromHtml(myOrder))
                .setNegativeButton("Close", null)
                .create();
        dialog.show();
    }

    private void processPayment() {
        amount = myPrice;
        PayPalPayment payPalPayment = new PayPalPayment(new BigDecimal(String.valueOf(amount)),"MYR",
                "Purchase Goods",PayPalPayment.PAYMENT_INTENT_SALE);
        Intent intent = new Intent(this, com.paypal.android.sdk.payments.PaymentActivity.class);
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION,config);
        intent.putExtra(PaymentActivity.EXTRA_PAYMENT,payPalPayment);
        startActivityForResult(intent,PAYPAL_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PAYPAL_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                PaymentConfirmation confirmation = data.getParcelableExtra(PaymentActivity.EXTRA_RESULT_CONFIRMATION);
                if (confirmation != null) {
                    try {
                        String paymentDetails = confirmation.toJSONObject().toString(4);
                        startActivity(new Intent(this, PaymentDetails.class)
                                .putExtra("Payment Details", paymentDetails)
                                .putExtra("Amount", amount)
                                .putExtra("ProgId", proId)
                                .putExtra("MyId", myId)
                                .putExtra("DispId", dispId)
                                .putExtra("MyLat", myLat)
                                .putExtra("MyLong", myLong)
                                .putExtra("MyRole", myRole)
                                .putExtra("MyEmail", myEmail)
                                .putExtra("MyService", myService));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            } else if (resultCode == Activity.RESULT_CANCELED)
                Toast.makeText(this, "Cancel", Toast.LENGTH_SHORT).show();
        } else if (resultCode == PaymentActivity.RESULT_EXTRAS_INVALID)
            Toast.makeText(this, "Invalid", Toast.LENGTH_SHORT).show();
    }
}
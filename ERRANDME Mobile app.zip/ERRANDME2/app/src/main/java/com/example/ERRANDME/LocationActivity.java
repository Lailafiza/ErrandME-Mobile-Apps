package com.example.ERRANDME;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.location.LocationServices;

import android.Manifest;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LocationActivity extends FragmentActivity implements OnMapReadyCallback,
        LocationListener,GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener{

    private GoogleMap mMap;
    String myLat, myLong, myEmail, exactId, locId, role, myAvailable = "1";
    Double myLat2, myLong2;
    android.location.Location mLastLocation;
    Marker mCurrLocationMarker;
    GoogleApiClient mGoogleApiClient;
    LocationRequest mLocationRequest;
    Button update, refresh, ready, back, stop;
    LatLng latLng;
    int already;
    private LocationManager locationManager;
    DatabaseReference databaseLocations;
    List<String> idList = new ArrayList<>();
    List<String> serviceList = new ArrayList<>();
    List<String> statusList = new ArrayList<>();
    List<String> nameList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        databaseLocations = FirebaseDatabase.getInstance().getReference("locations");
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map2);
        mapFragment.getMapAsync(this);

        myEmail = getIntent().getStringExtra("MailingLocation");

        update = findViewById(R.id.updateLoc);
        refresh = findViewById(R.id.refreshLoc);
        ready = findViewById(R.id.readyLoc);
        stop = findViewById(R.id.stopLoc);
        back = findViewById(R.id.back10);


        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = database.getReference("users");
        final DatabaseReference table_location = database.getReference("locations");
        final DatabaseReference table_notification = database.getReference("notifications");


        table_user.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    String myId = ds.child("userEmail").getValue().toString();

                    if (myEmail.equalsIgnoreCase(myId))
                    {
                        exactId = ds.child("userId").getValue().toString();
                        role = ds.child("userRole").getValue().toString();
                    }

                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        table_location.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    String luId = ds.child("locationUserID").getValue().toString();

                    if (exactId.equalsIgnoreCase(luId))
                    {
                        myLat = ds.child("locationLat").getValue().toString();
                        myLong = ds.child("locationLong").getValue().toString();
                        myAvailable = ds.child("locationAvailable").getValue().toString();
                        locId = ds.child("locationID").getValue().toString();
                    }

                }
                if(myAvailable.equalsIgnoreCase("1"))
                {
                    stop.setEnabled(false);
                }
                else if (myAvailable.equalsIgnoreCase("2"))
                {
                    ready.setEnabled(false);
                }

                if(myLat == null)
                {
                    ready.setEnabled(false);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        table_notification.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    if(role.equalsIgnoreCase("1"))
                    {
                        if(idList.size() != 0)
                        {
                            for (int i = 0; i < idList.size(); i++)
                            {
                                if(ds.child("notiProgId").getValue().toString().equalsIgnoreCase(idList.get(i).toString()))
                                {
                                    if(ds.child("notiCount").getValue().toString().equalsIgnoreCase("2") && statusList.get(i).toString().equalsIgnoreCase("Ongoing"))
                                    {
                                        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                                        String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "My Notifications", NotificationManager.IMPORTANCE_HIGH);

                                            // Configure the notification channel.
                                            notificationChannel.setDescription("Channel description");
                                            notificationChannel.enableLights(true);
                                            notificationChannel.setLightColor(Color.RED);
                                            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
                                            notificationChannel.enableVibration(true);
                                            notificationManager.createNotificationChannel(notificationChannel);
                                        }


                                        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(LocationActivity.this, NOTIFICATION_CHANNEL_ID);

                                        notificationBuilder.setAutoCancel(true)
                                                .setDefaults(android.app.Notification.DEFAULT_ALL)
                                                .setWhen(System.currentTimeMillis())
                                                .setSmallIcon(R.drawable.ic_shuttle)
                                                .setTicker("Hearty365")
                                                .setPriority(android.app.Notification.PRIORITY_MAX)
                                                .setContentTitle("My Errand ("+serviceList.get(i).toString()+")")
                                                .setContentText(Html.fromHtml("Dear Customer, your errand <b>("+idList.get(i).toString()+")</b> has been accepted by <b>"
                                                        +nameList.get(i).toString()+"</b>."));

                                        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle()
                                                .bigText(Html.fromHtml("Dear Customer, your errand <b>("+idList.get(i).toString()+")</b> has been accepted by <b>"
                                                        +nameList.get(i).toString()+"</b>."))
                                                .setBigContentTitle("My Errand ("+serviceList.get(i).toString()+")");

                                        notificationBuilder.setStyle(bigTextStyle);
                                        notificationBuilder.setPriority(NotificationCompat.PRIORITY_MAX);

                                        notificationManager.notify(/*notification id*/1, notificationBuilder.build());

                                        DatabaseReference dR = FirebaseDatabase.getInstance().getReference("notifications").child(ds.child("notiID").getValue().toString());
                                        com.example.ERRANDME.Notification notification = new com.example.ERRANDME.Notification(ds.child("notiID").getValue().toString(), "3", idList.get(i).toString());
                                        dR.setValue(notification);
                                    }
                                }
                            }
                        }
                    }
                    else if(role.equalsIgnoreCase("2"))
                    {
                        if(idList.size() != 0)
                        {
                            for (int i = 0; i < idList.size(); i++)
                            {
                                if(ds.child("notiProgId").getValue().toString().equalsIgnoreCase(idList.get(i).toString()))
                                {
                                    if(ds.child("notiCount").getValue().toString().equalsIgnoreCase("1") && statusList.get(i).toString().equalsIgnoreCase("Pending"))
                                    {
                                        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                                        String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "My Notifications", NotificationManager.IMPORTANCE_HIGH);

                                            // Configure the notification channel.
                                            notificationChannel.setDescription("Channel description");
                                            notificationChannel.enableLights(true);
                                            notificationChannel.setLightColor(Color.RED);
                                            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
                                            notificationChannel.enableVibration(true);
                                            notificationManager.createNotificationChannel(notificationChannel);
                                        }


                                        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(LocationActivity.this, NOTIFICATION_CHANNEL_ID);

                                        notificationBuilder.setAutoCancel(true)
                                                .setDefaults(android.app.Notification.DEFAULT_ALL)
                                                .setWhen(System.currentTimeMillis())
                                                .setSmallIcon(R.drawable.ic_shuttle)
                                                .setTicker("Hearty365")
                                                //     .setPriority(Notification.PRIORITY_MAX)
                                                .setContentTitle("Errand To Do ("+serviceList.get(i).toString()+")")
                                                .setContentText(Html.fromHtml("There is new errand request from <b>"+nameList.get(i).toString()+"</b>, <b>("+idList.get(i).toString()+")</b>."));

                                        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle()
                                                .bigText(Html.fromHtml("There is new errand request from <b>"+nameList.get(i).toString()+"</b>, <b>("+idList.get(i).toString()+")</b>."))
                                                .setBigContentTitle("Errand To Do ("+serviceList.get(i).toString()+")");

                                        notificationBuilder.setStyle(bigTextStyle);
                                        notificationBuilder.setPriority(NotificationCompat.PRIORITY_MAX);

                                        notificationManager.notify(/*notification id*/1, notificationBuilder.build());

                                        DatabaseReference dR = FirebaseDatabase.getInstance().getReference("notifications").child(ds.child("notiID").getValue().toString());
                                        com.example.ERRANDME.Notification notification = new com.example.ERRANDME.Notification(ds.child("notiID").getValue().toString(), "2", idList.get(i).toString());
                                        dR.setValue(notification);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});


        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                updateLocation();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentProfile = new Intent(LocationActivity.this, MainActivity.class);
                startActivity(intentProfile);
                finish();
            }
        });

        ready.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String loclac = String.valueOf(myLat);
                String loclong = String.valueOf(myLong);

                if(!loclac.isEmpty() && !loclong.isEmpty())
                {
                    DatabaseReference dR = FirebaseDatabase.getInstance().getReference("locations").child(locId);
                    Location location = new Location(locId, myLat, myLong, "2", exactId);
                    dR.setValue(location);

                    Toast.makeText(getApplicationContext(), "Ready Service", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(LocationActivity.this, LocationActivity.class);
                    intent.putExtra("MailingLocation", myEmail);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(LocationActivity.this, "Sorry cannot detect location!!!", Toast.LENGTH_LONG).show();
                }
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String loclac = String.valueOf(myLat);
                String loclong = String.valueOf(myLong);

                if(!loclac.isEmpty() && !loclong.isEmpty())
                {
                    DatabaseReference dR = FirebaseDatabase.getInstance().getReference("locations").child(locId);
                    Location location = new Location(locId, myLat, myLong, "1", exactId);
                    dR.setValue(location);

                    Toast.makeText(getApplicationContext(), "Stop Service", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(LocationActivity.this, LocationActivity.class);
                    intent.putExtra("MailingLocation", myEmail);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(LocationActivity.this, "Sorry cannot detect location!!!", Toast.LENGTH_LONG).show();
                }

            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String loclac = String.valueOf(myLat2);
                String loclong = String.valueOf(myLong2);

                if(!loclac.isEmpty() && !loclong.isEmpty())
                {
                    if(locId != null)
                    {
                        DatabaseReference dR = FirebaseDatabase.getInstance().getReference("locations").child(locId);
                        Location location = new Location(locId, loclac, loclong, myAvailable, exactId);
                        dR.setValue(location);
                    }
                    else
                    {
                        locId = databaseLocations.push().getKey();

                        //creating an Artist Object
                        Location location = new Location(locId, loclac, loclong, myAvailable, exactId);

                        //Saving the Artist
                        databaseLocations.child(locId).setValue(location);
                    }

                    Toast.makeText(getApplicationContext(), "Location Updated", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(LocationActivity.this, LocationActivity.class);
                    intent.putExtra("MailingLocation", myEmail);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(LocationActivity.this, "Sorry cannot detect location!!!", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    private void updateLocation() {

        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map2))
                .getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        checkLocation();

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mMap.setMyLocationEnabled(true);
            }
        }
        else {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
        }

    }
    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API).build();
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnected(Bundle bundle) {

        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onLocationChanged(android.location.Location location) {

        mLastLocation = location;
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }

        MarkerOptions markerOptions = new MarkerOptions();

        if (myLat == null || already == 1)
        {
            myLat2 = location.getLatitude();
            myLong2 = location.getLongitude();
        }
        else
        {
            myLat2 = Double.parseDouble(myLat);
            myLong2 = Double.parseDouble(myLong);
            already = 1;
        }
        latLng = new LatLng(myLat2, myLong2);
        markerOptions.position(latLng).draggable(true);
        markerOptions.title(getAddress(myLat2, myLong2));
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        mCurrLocationMarker = mMap.addMarker(markerOptions);

        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(16));

        if (mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }

    }


    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }

    private boolean checkLocation() {
        if(!isLocationEnabled())
            showAlert();
        return isLocationEnabled();
    }

    private void showAlert() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'. Please Enable Location to use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                });
        dialog.show();
    }

    private boolean isLocationEnabled() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    public String getAddress(double lat, double lng) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            Address obj = addresses.get(0);
            String add = obj.getAddressLine(0);
            add = add + "\n" + obj.getCountryName();
            add = add + "\n" + obj.getCountryCode();
            add = add + "\n" + obj.getAdminArea();
            add = add + "\n" + obj.getPostalCode();
            add = add + "\n" + obj.getSubAdminArea();
            add = add + "\n" + obj.getLocality();
            add = add + "\n" + obj.getSubThoroughfare();

            return add;

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "";
        }
    }
}
package com.example.ERRANDME;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    ListView HistoryListView;
    String myEmail, available, myId, myRole;
    private  Button back;
    List<String> idList = new ArrayList<>();
    List<String> contactList = new ArrayList<>();
    List<String> serviceList = new ArrayList<>();
    List<String> nameList = new ArrayList<>();
    List<String> priceList = new ArrayList<>();
    List<String> progList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        HistoryListView = findViewById(R.id.listviewHistory);
        back = findViewById(R.id.backHistory);

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = database.getReference("users");
        final DatabaseReference table_progress = database.getReference("progresss");


        myEmail = getIntent().getStringExtra("MailingHistory");
        available = getIntent().getStringExtra("Available");


        table_user.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    if(myEmail.equalsIgnoreCase(ds.child("userEmail").getValue().toString()))
                    {
                        myId = ds.child("userId").getValue().toString();
                        myRole = ds.child("userRole").getValue().toString();
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        table_progress.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    if(ds.child("progStatus").getValue().toString().equalsIgnoreCase("Complete"))
                    {
                        if(myRole.equalsIgnoreCase("1"))
                        {
                            if(myId.equalsIgnoreCase(ds.child("progCustID").getValue().toString()))
                            {
                                idList.add(ds.child("progDispID").getValue().toString());
                                serviceList.add(ds.child("progService").getValue().toString());
                                priceList.add("RM " + ds.child("progTotPrice").getValue().toString());
                                progList.add(ds.child("progID").getValue().toString());
                            }
                        }
                        else if (myRole.equalsIgnoreCase("2"))
                        {
                            if(myId.equalsIgnoreCase(ds.child("progDispID").getValue().toString()))
                            {
                                idList.add(ds.child("progCustID").getValue().toString());
                                serviceList.add(ds.child("progService").getValue().toString());
                                priceList.add("RM " + ds.child("progTotPrice").getValue().toString());
                                progList.add(ds.child("progID").getValue().toString());
                            }
                        }
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        table_user.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    if(idList != null)
                    {
                        for (int i = 0; i < idList.size(); i++)
                        {
                            if(idList.get(i).toString().equalsIgnoreCase(ds.child("userId").getValue().toString()))
                            {
                                nameList.add(ds.child("userName").getValue().toString());
                                contactList.add(ds.child("userPhoneNum").getValue().toString());
                            }
                        }
                    }
                }

                    if  (nameList != null)
                    {
                        HistoryListView.setVisibility(View.VISIBLE);

                        ListAdapter2Class adapter = new ListAdapter2Class(nameList, contactList, serviceList,
                                priceList, HistoryActivity.this);

                        HistoryListView.setAdapter(adapter);
                    }
                }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentProfile = new Intent(HistoryActivity.this, MainActivity.class);
                startActivity(intentProfile);
                finish();
            }
        });
    }
}
package com.example.ERRANDME;

public class User {

    private String UserId;
    private String UserEmail;
    private String UserPassword;
    private String UserName;
    private String UserPhoneNum;
    private String UserRole;


    public User(){

    }

    public User (String UserId, String UserEmail, String UserPassword, String UserName,String UserPhoneNum,
                 String UserRole){
        this.UserId = UserId;
        this.UserEmail = UserEmail;
        this.UserPassword = UserPassword;
        this.UserName = UserName;
        this.UserPhoneNum = UserPhoneNum;
        this.UserRole = UserRole;

    }

    public String getUserId (){
        return UserId;
    }

    public String getUserEmail() {
        return UserEmail;
    }

    public String getUserPassword() {
        return UserPassword;
    }

    public String getUserName(){
        return UserName;
    }

    public String getUserPhoneNum() {
        return UserPhoneNum;
    }

    public String getUserRole() {
        return UserRole;
    }


}

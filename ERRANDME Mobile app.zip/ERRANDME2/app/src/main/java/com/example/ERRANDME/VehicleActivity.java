package com.example.ERRANDME;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class VehicleActivity extends AppCompatActivity {

    private EditText VeName, VePNum ;
    private Button btnVeBack, btnVeUpdate;
    private Spinner VeType;
    String myEmail, myId, TypeHolder, VeId;
    DatabaseReference databaseVehicles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle);

        databaseVehicles = FirebaseDatabase.getInstance().getReference("vehicles");

        VeName = findViewById(R.id.VName);
        VeType = findViewById(R.id.VType);
        VePNum = findViewById(R.id.VPNum);
        btnVeUpdate = findViewById(R.id.btnVUpdate);
        btnVeBack = findViewById(R.id.btnVBack);

        myEmail = getIntent().getStringExtra("MailingVehicle");
        myId = getIntent().getStringExtra("IdVehicle");

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_vehicle = database.getReference("vehicles");

        table_vehicle.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    String VeUId = ds.child("vehicleUserId").getValue().toString();

                    if (myId.equalsIgnoreCase(VeUId))
                    {
                        VeName.setText(ds.child("vehicleName").getValue().toString());
                        TypeHolder = ds.child("vehicleType").getValue().toString();
                        VePNum.setText(ds.child("vehiclePNum").getValue().toString());
                        VeId = ds.child("vehicleId").getValue().toString();
                    }
                }
                addItemsOnSpinner();
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        btnVeUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String vname = VeName.getText().toString().trim();
                String vtype = String.valueOf(VeType.getSelectedItem());
                String vpnum =  VePNum.getText().toString().toUpperCase();

                if(!vname.isEmpty() && !vpnum.isEmpty())
                {
                    if(VeId != null)
                    {
                        DatabaseReference dR = FirebaseDatabase.getInstance().getReference("vehicles").child(VeId);
                        Vehicle vehicle = new Vehicle(VeId, vname, vtype, vpnum, myId);
                        dR.setValue(vehicle);
                    }
                    else
                    {
                        VeId = databaseVehicles.push().getKey();

                        //creating an vehicle Object
                        Vehicle vehicle = new Vehicle(VeId, vname, vtype, vpnum, myId);

                        //Saving the vehicle
                        databaseVehicles.child(VeId).setValue(vehicle);
                    }

                    Toast.makeText(getApplicationContext(), "Vehicle Updated", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(VehicleActivity.this, VehicleActivity.class);
                    intent.putExtra("MailingVehicle", myEmail);
                    intent.putExtra("IdVehicle", myId);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(VehicleActivity.this, "Empty vehicle name or number plate!!!", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnVeBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VehicleActivity.this, UserProfileActivity.class);
                intent.putExtra("Mailing", myEmail);
                startActivity(intent);
                finish();
            }
        });
    }

    public void addItemsOnSpinner() {

        List<String> list = new ArrayList<String>();
        list.add("Motorcycle");
        list.add("Car");
        list.add("Lorry/Van");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        VeType.setAdapter(dataAdapter);
        if(TypeHolder != null)
        {
            int pos = dataAdapter.getPosition(TypeHolder);
            VeType.setSelection(pos);
        }
    }
}

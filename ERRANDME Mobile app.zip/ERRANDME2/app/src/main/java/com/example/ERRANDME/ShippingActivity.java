package com.example.ERRANDME;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;


import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ShippingActivity extends FragmentActivity implements OnMapReadyCallback,
        LocationListener,GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener{

    private EditText etShipWeight;
    private Spinner ShipType, ShipVehicle;
    private Button btnShipsubmit, btnShipback, clear;
    private CheckBox ckShipFragile;
    private TextView tvShipFInfo,tvShipDistance;
    private String fragilemode = "2";
    private SearchView Searchview;
    private GoogleMap mMap;
    String myEmail;
    Location mLastLocation;
    Marker mCurrLocationMarker, destination;
    GoogleApiClient mGoogleApiClient;
    LocationRequest mLocationRequest;
    private LocationManager locationManager;
    Double myLat2, myLong2, destLat, destLong;
    LatLng latLng;
    Double distance;
    LatLng latLng2;
    DecimalFormat newFormat = new DecimalFormat("#####0.00");
    private int LOCATION_PERMISSION_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipping);

        etShipWeight = findViewById(R.id.shipWeight);
        ShipType = findViewById(R.id.shipType);
        ShipVehicle = findViewById(R.id.shipVehicle);
        ckShipFragile = findViewById(R.id.shipFragile);
        tvShipDistance = findViewById(R.id.tvShipDist);
        tvShipFInfo = findViewById(R.id.tvShipFInfo);
        clear = findViewById(R.id.clearShipText);
        btnShipsubmit = findViewById(R.id.btnShipSubmit);
        btnShipback = findViewById(R.id.btnShipBack);
        Searchview = findViewById(R.id.search);

        myEmail = getIntent().getStringExtra("MailingShip");

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map3);
        mapFragment.getMapAsync(this);

        Searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                String location =  Searchview.getQuery().toString();
                List<Address> addressList = null;

                if (destination != null) {
                    destination.remove();
                }

                if(location != null || !location.equals(""))
                {
                    Geocoder geocoder = new Geocoder(ShippingActivity.this);
                    try {
                        addressList = geocoder.getFromLocationName(location, 1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Address address = addressList.get(0);
                    latLng2 = new LatLng(address.getLatitude(), address.getLongitude());
                    destLat = address.getLatitude();
                    destLong = address.getLongitude();
                    destination = mMap.addMarker(new MarkerOptions().position(latLng2).title(location));
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng2, 9));

                    distance = CalculationByDistance(latLng, latLng2);
                    tvShipDistance.setText(Double.toString(distance));
                    if(distance > 30)
                    {
                        btnShipsubmit.setVisibility(View.GONE);

                    }
                    else
                    {
                        btnShipsubmit.setVisibility(View.VISIBLE);

                    }
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        ckShipFragile.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton button,
                                                 boolean isChecked) {
                        if (isChecked) {

                            tvShipFInfo.setVisibility(View.VISIBLE);
                            fragilemode = "1";

                        } else {
                            tvShipFInfo.setVisibility(View.GONE);
                            fragilemode = "2";
                        }
                    }
                });

        addItemsOnSpinner();
        addItemsOnSpinner2();


        btnShipsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!myEmail.isEmpty() && ! tvShipDistance.getText().toString().isEmpty() && ! etShipWeight.getText().toString().isEmpty() && !fragilemode.isEmpty()
                        && ! String.valueOf(ShipVehicle.getSelectedItem()).isEmpty() && ! String.valueOf(ShipType.getSelectedItem()).isEmpty() && ! String.valueOf(myLat2).isEmpty()
                        && ! String.valueOf(myLong2).isEmpty() && ! String.valueOf(destLat).isEmpty() && ! String.valueOf(destLong).isEmpty())
                {
                    Intent intentProfile = new Intent(ShippingActivity.this, PaymentActivity.class);
                    intentProfile.putExtra("MailingPayment", myEmail);
                    intentProfile.putExtra("Distance",  tvShipDistance.getText().toString());
                    intentProfile.putExtra("Weight",  etShipWeight.getText().toString());
                    intentProfile.putExtra("Fragile", fragilemode);
                    intentProfile.putExtra("VehiclingShip", String.valueOf(ShipVehicle.getSelectedItem()));
                    intentProfile.putExtra("TypeShip", String.valueOf(  ShipType.getSelectedItem()));
                    intentProfile.putExtra("StartLat", String.valueOf(myLat2));
                    intentProfile.putExtra("StartLong", String.valueOf(myLong2));
                    intentProfile.putExtra("EndLat", String.valueOf(destLat));
                    intentProfile.putExtra("EndLong", String.valueOf(destLong));
                    startActivity(intentProfile);
                    finish();
                }
                else
                {
                    Toast.makeText(ShippingActivity.this, "Please complete your errand!!!", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnShipback.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShippingActivity.this, ServiceActivity.class);
                intent.putExtra("MailingService", myEmail);
                startActivity(intent);
                finish();
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShipType.setSelection(0);
                etShipWeight.setText("");
                ShipVehicle.setSelection(0);
                ckShipFragile.setChecked(false);
                if (destination != null) {
                    destination.remove();
                }
            }
        });
    }


    public void addItemsOnSpinner() {

        List<String> list = new ArrayList<String>();
        list.add("Parcel / Document");
        list.add("Food / Drinks");
        list.add("Others");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ShipType.setAdapter(dataAdapter);
    }

    public void addItemsOnSpinner2() {

        List<String> list = new ArrayList<String>();
        list.add("Motorcycle");
        list.add("Car");
        list.add("Van/Lorry");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ShipVehicle.setAdapter(dataAdapter);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        checkLocation();

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)  == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mMap.setMyLocationEnabled(true);
            }
        }
        else {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
        }

    }
    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API).build();
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnected(Bundle bundle) {

        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onLocationChanged(Location location) {

        mLastLocation = location;
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }

        MarkerOptions markerOptions = new MarkerOptions();

        myLat2 = location.getLatitude();
        myLong2 = location.getLongitude();

        latLng = new LatLng(myLat2, myLong2);
        markerOptions.position(latLng).draggable(true);
        markerOptions.title(getAddress(myLat2, myLong2));
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        mCurrLocationMarker = mMap.addMarker(markerOptions);

        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(9));
        Circle circle = mMap.addCircle(new CircleOptions()
                .center(latLng)
                .radius(30000)
                .strokeColor(Color.argb(50, 113,204, 231))
                .fillColor(Color.argb(50, 113,204, 231)));

        if (mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }

    private boolean checkLocation() {
        if(!isLocationEnabled())
            showAlert();
        return isLocationEnabled();
    }

    private void showAlert() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'. Please Enable Location to use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                });
        dialog.show();
    }

    private boolean isLocationEnabled() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    public String getAddress(double lat, double lng) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            Address obj = addresses.get(0);
            String add = obj.getAddressLine(0);
            add = add + "\n" + obj.getCountryName();
            add = add + "\n" + obj.getCountryCode();
            add = add + "\n" + obj.getAdminArea();
            add = add + "\n" + obj.getPostalCode();
            add = add + "\n" + obj.getSubAdminArea();
            add = add + "\n" + obj.getLocality();
            add = add + "\n" + obj.getSubThoroughfare();

            return add;

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "";
        }
    }

    public double CalculationByDistance(LatLng StartP, LatLng EndP) {
        int Radius = 6371;
        double lat1 = StartP.latitude;
        double lat2 = EndP.latitude;
        double lon1 = StartP.longitude;
        double lon2 = EndP.longitude;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                * Math.sin(dLon / 2);
        double c = 2 * Math.asin(Math.sqrt(a));
        double valueResult = Radius * c;
        double km = valueResult / 1;
        double kmInDec = Double.valueOf(newFormat.format(km));

        return kmInDec;
    }
}


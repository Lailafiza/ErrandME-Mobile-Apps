package com.example.ERRANDME;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.ERRANDME.Config.Config;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.paypal.android.sdk.payments.PayPalConfiguration;
import com.paypal.android.sdk.payments.PayPalPayment;
import com.paypal.android.sdk.payments.PayPalService;
import com.paypal.android.sdk.payments.PaymentActivity;
import com.paypal.android.sdk.payments.PaymentConfirmation;
import org.json.JSONException;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Locale;

public class ShipActivity extends FragmentActivity implements OnMapReadyCallback,
        LocationListener, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {

    private static final int PAYPAL_REQUEST_CODE = 7777;

    private static PayPalConfiguration config = new PayPalConfiguration()
            .environment(PayPalConfiguration.ENVIRONMENT_SANDBOX)
            .clientId(Config.PAYPAL_CLIENT_ID);

    String myEmail, myId, myRole, proId, myService, custId, dispId, status, dispName, dispContact, custName, custContact, vName, vPlate, vType, vNeed,
            jenis, berat, harga, frag, myLat, myLong, myPrice, sLat, sLong, eLat, eLong, id, amount;
    private TextView name, vehicle, service, type, weight, payment, fragile;
    private ImageView pending, ongoing, dispatch, complete, confirm, paid;
    private View lbtn, lvehicle, lbtn2;
    private ImageButton call, ws;
    private Button cancel, accept, reject, btnItem, btnComplete, btnConfirm, back, paypal, cod;
    private int LOCATION_PERMISSION_CODE = 1;
    private Context mContext;
    private Activity mActivity;
    private GoogleMap mMap;
    private SupportMapFragment mapFragment;
    private static final int MY_PERMISSION_REQUEST_CODE = 123;
    Location mLastLocation;
    Marker mCurrLocationMarker;
    GoogleApiClient mGoogleApiClient;
    LocationRequest mLocationRequest;
    private LocationManager locationManager;
    DecimalFormat newFormat = new DecimalFormat("#####0.00");
    Double LatStart, LongStart, distance;

    @Override
    protected void onDestroy() {
        stopService(new Intent(this, PayPalService.class));
        super.onDestroy();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship);

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_CODE);
        }

        mContext = getApplicationContext();
        mActivity = ShipActivity.this;

        name = findViewById(R.id.info1S);
        vehicle = findViewById(R.id.info2S);
        call = findViewById(R.id.callS);
        ws = findViewById(R.id.wsS);
        service = findViewById(R.id.item1S);
        type = findViewById(R.id.item2S);
        weight = findViewById(R.id.item3S);
        payment = findViewById(R.id.item4S);
        fragile = findViewById(R.id.item5S);
        pending = findViewById(R.id.status1S);
        ongoing = findViewById(R.id.status2S);
        dispatch = findViewById(R.id.status3S);
        complete = findViewById(R.id.status4S);
        confirm = findViewById(R.id.status5S);
        cancel = findViewById(R.id.cancelS);
        accept = findViewById(R.id.acceptS);
        reject = findViewById(R.id.rejectS);
        btnItem = findViewById(R.id.itemS);
        btnComplete = findViewById(R.id.completeS);
        btnConfirm = findViewById(R.id.confirmS);
        back = findViewById(R.id.backS);
        lbtn = findViewById(R.id.layoutS);
        lvehicle = findViewById(R.id.layoutVehicle2);
        lbtn2 = findViewById(R.id.layoutS2);
        paypal = findViewById(R.id.paypalS);
        cod = findViewById(R.id.codS);
        paid = findViewById(R.id.status6S);

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = database.getReference("users");
        final DatabaseReference table_progress = database.getReference("progresss");
        final DatabaseReference table_shipping = database.getReference("shippings");
        final DatabaseReference table_vehicle = database.getReference("vehicles");

        proId = getIntent().getStringExtra("ProgId");
        myId = getIntent().getStringExtra("MyId");
        myRole = getIntent().getStringExtra("MyRole");
        myEmail = getIntent().getStringExtra("MyEmail");
        myService = getIntent().getStringExtra("MyService");

        table_progress.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    if (proId.equalsIgnoreCase(ds.child("progID").getValue().toString())) {
                        if (myRole.equalsIgnoreCase("1")) {
                            dispId = ds.child("progDispID").getValue().toString();
                            status = ds.child("progStatus").getValue().toString();
                            myPrice = ds.child("progTotPrice").getValue().toString();
                            myLat = ds.child("progLat").getValue().toString();
                            myLong = ds.child("progLong").getValue().toString();

                        } else if (myRole.equalsIgnoreCase("2")) {
                            custId = ds.child("progCustID").getValue().toString();
                            status = ds.child("progStatus").getValue().toString();
                            myPrice = ds.child("progTotPrice").getValue().toString();
                            myLat = ds.child("progLat").getValue().toString();
                            myLong = ds.child("progLong").getValue().toString();

                        }
                    }
                }
                if (status.equalsIgnoreCase("Pending")) {
                    ongoing.setVisibility(View.INVISIBLE);
                    paid.setVisibility(View.INVISIBLE);
                    dispatch.setVisibility(View.INVISIBLE);
                    confirm.setVisibility(View.INVISIBLE);
                    complete.setVisibility(View.INVISIBLE);
                } else if (status.equalsIgnoreCase("Ongoing")) {
                    paid.setVisibility(View.INVISIBLE);
                    dispatch.setVisibility(View.INVISIBLE);
                    confirm.setVisibility(View.INVISIBLE);
                    complete.setVisibility(View.INVISIBLE);
                } else if (status.equalsIgnoreCase("PaymentCOD") || status.equalsIgnoreCase("PaymentPaypal")) {
                    dispatch.setVisibility(View.INVISIBLE);
                    confirm.setVisibility(View.INVISIBLE);
                    complete.setVisibility(View.INVISIBLE);
                }else if (status.equalsIgnoreCase("Dispatching")) {
                    confirm.setVisibility(View.INVISIBLE);
                    complete.setVisibility(View.INVISIBLE);
                } else if (status.equalsIgnoreCase("Confirm")) {
                    complete.setVisibility(View.INVISIBLE);
                }

                if(myRole.equalsIgnoreCase("1"))
                {
                    if(status.equalsIgnoreCase("Pending"))
                    {
                        cancel.setVisibility(View.VISIBLE);
                    }
                    else if (status.equalsIgnoreCase("Ongoing"))
                    {
                        lbtn2.setVisibility(View.VISIBLE);
                    }
                    else if (status.equalsIgnoreCase("Confirm"))
                    {
                        btnComplete.setVisibility(View.VISIBLE);
                    }
                }
                else if (myRole.equalsIgnoreCase("2"))
                {
                    if(status.equalsIgnoreCase("Pending"))
                    {
                        lbtn.setVisibility(View.VISIBLE);
                    }
                    else if(status.equalsIgnoreCase("PaymentCOD") || status.equalsIgnoreCase("PaymentPaypal"))
                    {
                        btnItem.setVisibility(View.VISIBLE);
                    }
                    else if(status.equalsIgnoreCase("Dispatching"))
                    {
                        btnConfirm.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        table_user.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    if (myRole.equalsIgnoreCase("1")) {
                        if (dispId.equalsIgnoreCase(ds.child("userId").getValue().toString())) {
                            dispName = ds.child("userName").getValue().toString();
                            dispContact = ds.child("userPhoneNum").getValue().toString();
                        }
                    } else if (myRole.equalsIgnoreCase("2")) {
                        if (custId.equalsIgnoreCase(ds.child("userId").getValue().toString())) {
                            custName = ds.child("userName").getValue().toString();
                            custContact = ds.child("userPhoneNum").getValue().toString();
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map8);

        table_vehicle.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    if (myRole.equalsIgnoreCase("1")) {
                        if (dispId.equalsIgnoreCase(ds.child("vehicleUserId").getValue().toString())) {
                            vName = ds.child("vehicleName").getValue().toString();
                            vPlate = ds.child("vehiclePNum").getValue().toString();
                            vType = ds.child("vehicleType").getValue().toString();
                        }
                    } else if (myRole.equalsIgnoreCase("2")) {
                        vNeed = "Dont";
                    }
                }
                if (myRole.equalsIgnoreCase("1")) {
                    name.setText(dispName + " (Disptacher)");
                    vehicle.setText(vType + "\n" + vName + " (" + vPlate + ")");
                    mapFragment.getView().setVisibility(View.GONE);
                } else if (myRole.equalsIgnoreCase("2")) {
                    name.setText(custName + " (Customer)");
                    lvehicle.setVisibility(View.GONE);
                    mapFragment.getMapAsync(ShipActivity.this);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        table_shipping.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    if (proId.equalsIgnoreCase(ds.child("shippingPId").getValue().toString())) {
                        frag = ds.child("shippingFragile").getValue().toString();
                        berat = ds.child("shippingWeight").getValue().toString();
                        jenis = ds.child("shippingType").getValue().toString();
                        harga = ds.child("shippingIPrice").getValue().toString();
                        sLat = ds.child("shippingStartedLat").getValue().toString();
                        sLong = ds.child("shippingStartedLong").getValue().toString();
                        eLat = ds.child("shippingDestinationLat").getValue().toString();
                        eLong = ds.child("shippingDestinationLong").getValue().toString();
                        id = ds.child("shippingId").getValue().toString();
                    }
                }

                service.setText(myService);
                type.setText(jenis);
                weight.setText(berat);
                if(myPrice.equalsIgnoreCase("0"))
                {
                    payment.setText(harga);
                }
                else
                {
                    payment.setText(myPrice);
                }
                if(frag.equalsIgnoreCase("1"))
                {
                    fragile.setText("Yes");
                }
                else if (frag.equalsIgnoreCase("2"))
                {
                    fragile.setText("No");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        Intent intenting = new Intent(this,PayPalService.class);
        intenting.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION,config);
        startService(intenting);

        ws.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (myRole.equalsIgnoreCase("1")) {
                    String url = "https://api.whatsapp.com/send?phone=" + "+6"+dispContact;
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                } else if (myRole.equalsIgnoreCase("2")) {
                    String url = "https://api.whatsapp.com/send?phone=" + "+6"+custContact;
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
            }
        });

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkPermission();
                } else {
                    CallContact();
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentProfile = new Intent(ShipActivity.this, StatusActivity.class);
                intentProfile.putExtra("MailingStatus", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                dR.removeValue();

                DatabaseReference dR2 = FirebaseDatabase.getInstance().getReference("shippings").child(id);
                dR2.removeValue();

                Toast.makeText(getApplicationContext(), "Canceling Order", Toast.LENGTH_LONG).show();
                Intent intentProfile = new Intent(ShipActivity.this, StatusActivity.class);
                intentProfile.putExtra("MailingStatus", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        cod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(proId, myService, "PaymentCOD", myPrice,
                        myLat, myLong, myId, dispId);
                dR.setValue(progress);

                Toast.makeText(getApplicationContext(), "Pay when dispatcher arrived", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ShipActivity.this, ShipActivity.class);
                intent.putExtra("ProgId", proId);
                intent.putExtra("MyId", myId);
                intent.putExtra("MyRole", myRole);
                intent.putExtra("MyEmail", myEmail);
                intent.putExtra("MyService", myService);
                startActivity(intent);
                finish();
            }
        });

        paypal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                processPayment();
            }
        });

        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(proId, myService, "Ongoing", myPrice,
                        myLat, myLong, custId, myId);
                dR.setValue(progress);

                Toast.makeText(getApplicationContext(), "Accepting Order", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ShipActivity.this, ShipActivity.class);
                intent.putExtra("ProgId", proId);
                intent.putExtra("MyId", myId);
                intent.putExtra("MyRole", myRole);
                intent.putExtra("MyEmail", myEmail);
                intent.putExtra("MyService", myService);
                startActivity(intent);
                finish();
            }
        });

        reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                dR.removeValue();

                DatabaseReference dR2 = FirebaseDatabase.getInstance().getReference("shippings").child(id);
                dR2.removeValue();

                Toast.makeText(getApplicationContext(), "Rejecting Order", Toast.LENGTH_LONG).show();
                Intent intentProfile = new Intent(ShipActivity.this, StatusActivity.class);
                intentProfile.putExtra("MailingStatus", myEmail);
                startActivity(intentProfile);
                finish();
            }
        });

        btnItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(proId, myService, "Dispatching",
                        harga, myLat, myLong, custId, myId);
                dR.setValue(progress);

                Toast.makeText(getApplicationContext(), "Update Order", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ShipActivity.this, ShipActivity.class);
                intent.putExtra("ProgId", proId);
                intent.putExtra("MyId", myId);
                intent.putExtra("MyRole", myRole);
                intent.putExtra("MyEmail", myEmail);
                intent.putExtra("MyService", myService);
                startActivity(intent);
                finish();
            }
        });

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(proId, myService, "Confirm",
                        myPrice, myLat, myLong, custId, myId);
                dR.setValue(progress);

                Toast.makeText(getApplicationContext(), "Item delivery", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ShipActivity.this, ShipActivity.class);
                intent.putExtra("ProgId", proId);
                intent.putExtra("MyId", myId);
                intent.putExtra("MyRole", myRole);
                intent.putExtra("MyEmail", myEmail);
                intent.putExtra("MyService", myService);
                startActivity(intent);
                finish();
            }
        });

        btnComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference dR = FirebaseDatabase.getInstance().getReference("progresss").child(proId);
                com.example.ERRANDME.Progress progress = new com.example.ERRANDME.Progress(proId, myService, "Complete",
                        myPrice, myLat, myLong, myId, dispId);
                dR.setValue(progress);

                Toast.makeText(getApplicationContext(), "Mission Success", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ShipActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    protected void CallContact() {
        Intent intent = new Intent(Intent.ACTION_CALL);
        // Send phone number to intent as data

        if(myRole.equalsIgnoreCase("1"))
        {
            intent.setData(Uri.parse("tel:" + "+6"+dispContact));
        }
        else if (myRole.equalsIgnoreCase("2"))
        {
            intent.setData(Uri.parse("tel:" + "+6"+custContact));
        }

        // Start the dialer app activity to make phone call
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(intent);

    }

    protected void checkPermission(){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
            if(checkSelfPermission(Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
                if(shouldShowRequestPermissionRationale(Manifest.permission.CALL_PHONE)){
                    // show an alert dialog
                    AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
                    builder.setMessage("Call Phone permission is required.");
                    builder.setTitle("Please grant permission");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ActivityCompat.requestPermissions(
                                    mActivity,
                                    new String[]{Manifest.permission.CALL_PHONE},
                                    MY_PERMISSION_REQUEST_CODE
                            );
                        }
                    });
                    builder.setNeutralButton("Cancel",null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }else {
                    // Request permission
                    ActivityCompat.requestPermissions(
                            mActivity,
                            new String[]{Manifest.permission.CALL_PHONE},
                            MY_PERMISSION_REQUEST_CODE
                    );
                }
            }else {
                // Permission already granted
                CallContact();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        switch(requestCode){
            case MY_PERMISSION_REQUEST_CODE:{
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    // Permission granted
                    CallContact();
                }else {
                    // Permission denied
                }
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        checkLocation();

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mMap.setMyLocationEnabled(true);
            }
        }
        else {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
        }

    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API).build();
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnected(Bundle bundle) {

        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onLocationChanged(Location location) {

        mMap.clear();
        mLastLocation = location;
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }

        LatStart = location.getLatitude();
        LongStart = location.getLongitude();
        LatLng latLng = new LatLng(LatStart, LongStart);

        MarkerOptions marker = new MarkerOptions().position(new LatLng(Double.valueOf(sLat), Double.valueOf(sLong)))
                .title(getAddress(Double.valueOf(sLat), Double.valueOf(sLong)))
                .snippet("Starting")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        mMap.addMarker(marker);

        MarkerOptions marker2 = new MarkerOptions().position(new LatLng(Double.valueOf(eLat), Double.valueOf(eLong)))
                .title(getAddress(Double.valueOf(eLat), Double.valueOf(eLong)))
                .snippet("Destination")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        mMap.addMarker(marker2);

        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("Your Location");
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
        mCurrLocationMarker = mMap.addMarker(markerOptions);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

        mMap.animateCamera(CameraUpdateFactory.zoomTo(10));
        Circle circle = mMap.addCircle(new CircleOptions()
                .center(latLng)
                .radius(10000)
                .strokeColor(Color.argb(0, 113,204, 231))
                .fillColor(Color.argb(0, 113,204, 231)));

        if (mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }

    private boolean checkLocation() {
        if(!isLocationEnabled())
            showAlert();
        return isLocationEnabled();
    }

    private void showAlert() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'. Please Enable Location to use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                });
        dialog.show();
    }

    private boolean isLocationEnabled() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    public String getAddress(double lat, double lng) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            Address obj = addresses.get(0);
            String add = obj.getAddressLine(0);
            add = add + "\n" + obj.getCountryName();
            add = add + "\n" + obj.getCountryCode();
            add = add + "\n" + obj.getAdminArea();
            add = add + "\n" + obj.getPostalCode();
            add = add + "\n" + obj.getSubAdminArea();
            add = add + "\n" + obj.getLocality();
            add = add + "\n" + obj.getSubThoroughfare();

            return add;

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "";
        }
    }

    private void processPayment() {
        if(myPrice.equalsIgnoreCase("0"))
        {
            amount = harga;
        }
        else
        {
            amount = myPrice;
        }
        PayPalPayment payPalPayment = new PayPalPayment(new BigDecimal(String.valueOf(amount)),"MYR",
                "Purchase Goods",PayPalPayment.PAYMENT_INTENT_SALE);
        Intent intent = new Intent(this, com.paypal.android.sdk.payments.PaymentActivity.class);
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION,config);
        intent.putExtra(com.paypal.android.sdk.payments.PaymentActivity.EXTRA_PAYMENT,payPalPayment);
        startActivityForResult(intent,PAYPAL_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PAYPAL_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                PaymentConfirmation confirmation = data.getParcelableExtra(com.paypal.android.sdk.payments.PaymentActivity.EXTRA_RESULT_CONFIRMATION);
                if (confirmation != null) {
                    try {
                        String paymentDetails = confirmation.toJSONObject().toString(4);
                        startActivity(new Intent(this, PaymentDetails.class)
                                .putExtra("Payment Details", paymentDetails)
                                .putExtra("Amount", amount)
                                .putExtra("ProgId", proId)
                                .putExtra("MyId", myId)
                                .putExtra("DispId", dispId)
                                .putExtra("MyLat", myLat)
                                .putExtra("MyLong", myLong)
                                .putExtra("MyRole", myRole)
                                .putExtra("MyEmail", myEmail)
                                .putExtra("MyService", myService));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            } else if (resultCode == Activity.RESULT_CANCELED)
                Toast.makeText(this, "Cancel", Toast.LENGTH_SHORT).show();
        } else if (resultCode == PaymentActivity.RESULT_EXTRAS_INVALID)
            Toast.makeText(this, "Invalid", Toast.LENGTH_SHORT).show();
    }
}
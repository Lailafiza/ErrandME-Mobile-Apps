package com.example.ERRANDME;

public class Vehicle {

    private String vehicleId;
    private String vehicleName;
    private String vehicleType;
    private String vehiclePNum;
    private String vehicleUserId;


    public Vehicle(){

    }

    public Vehicle (String vehicleId, String vehicleName, String vehicleType,String vehiclePNum, String vehicleUserId) {
        this.vehicleId = vehicleId;
        this.vehicleName = vehicleName;
        this.vehicleType = vehicleType;
        this.vehiclePNum = vehiclePNum;
        this.vehicleUserId = vehicleUserId;
    }

    public String getVehicleId (){
        return vehicleId;
    }

    public String getVehicleName (){
        return vehicleName;
    }

    public String getVehicleType (){
        return vehicleType;
    }

    public String getVehiclePNum (){
        return vehiclePNum;
    }

    public String getVehicleUserId (){
        return vehicleUserId;
    }
}
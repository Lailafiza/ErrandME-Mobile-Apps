package com.example.ERRANDME;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;


public class StatusActivity extends AppCompatActivity {

    ListView StatusListView;
    String myEmail, myId, myRole, available;
    private  Button back;
    List<String> idList = new ArrayList<>();
    List<String> serviceList = new ArrayList<>();
    List<String> statusList = new ArrayList<>();
    List<String> nameList = new ArrayList<>();
    List<String> progList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);

        StatusListView = findViewById(R.id.listviewStatus);
        back = findViewById(R.id.backStatus);

        //declare database
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = database.getReference("users");
        final DatabaseReference table_progress = database.getReference("progresss");

        //declare name for passing data
        myEmail = getIntent().getStringExtra("MailingStatus");
        available = getIntent().getStringExtra("Available");

        //retrive data from database
        table_user.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    if(myEmail.equalsIgnoreCase(ds.child("userEmail").getValue().toString()))
                    {
                        myId = ds.child("userId").getValue().toString();
                        myRole = ds.child("userRole").getValue().toString();
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        //retrieve data from database
        table_progress.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    if(!ds.child("progStatus").getValue().toString().equalsIgnoreCase("Complete"))
                    {
                        if(myRole.equalsIgnoreCase("1"))
                        {
                            if(myId.equalsIgnoreCase(ds.child("progCustID").getValue().toString()))
                            {
                                serviceList.add(ds.child("progService").getValue().toString());
                                statusList.add(ds.child("progStatus").getValue().toString());
                                idList.add(ds.child("progDispID").getValue().toString());
                                progList.add(ds.child("progID").getValue().toString());
                            }
                        }
                        else if (myRole.equalsIgnoreCase("2"))
                        {
                            if(myId.equalsIgnoreCase(ds.child("progDispID").getValue().toString()))
                            {
                                serviceList.add(ds.child("progService").getValue().toString());
                                statusList.add(ds.child("progStatus").getValue().toString());
                                idList.add(ds.child("progCustID").getValue().toString());
                                progList.add(ds.child("progID").getValue().toString());
                            }
                        }
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        //retrieve data from database
        table_user.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    if(idList != null)
                    {
                        for (int i = 0; i < idList.size(); i++)
                        {
                            if(idList.get(i).toString().equalsIgnoreCase(ds.child("userId").getValue().toString()))
                            {
                                nameList.add(ds.child("userName").getValue().toString());
                            }
                        }
                    }
                    if  (nameList != null)
                    {
                        StatusListView.setVisibility(View.VISIBLE);

                        ListAdapterClass adapter = new ListAdapterClass(nameList, serviceList, statusList, StatusActivity.this);

                        StatusListView.setAdapter(adapter);
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});

        //ni nak retrive data dr activity lain ke activity ni dalam bentuk list
        StatusListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                if(serviceList.get(position).toString().equalsIgnoreCase("FastFood") || serviceList.get(position).toString().equalsIgnoreCase("Shopping"))
                {
                    Intent intent = new Intent(StatusActivity.this, FoodShopActivity.class);
                    intent.putExtra("ProgId", progList.get(position).toString());
                    intent.putExtra("MyId", myId);
                    intent.putExtra("MyRole", myRole);
                    intent.putExtra("MyEmail", myEmail);
                    intent.putExtra("MyService", serviceList.get(position).toString());
                    startActivity(intent);
                    finish();
                }
                else if(serviceList.get(position).toString().equalsIgnoreCase("Shipping"))
                {
                    Intent intent = new Intent(StatusActivity.this, ShipActivity.class);
                    intent.putExtra("ProgId", progList.get(position).toString());
                    intent.putExtra("MyId", myId);
                    intent.putExtra("MyRole", myRole);
                    intent.putExtra("MyEmail", myEmail);
                    intent.putExtra("MyService", serviceList.get(position).toString());
                    startActivity(intent);
                    finish();
                }

                return false;
            }
        });

        //button back
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentProfile = new Intent(StatusActivity.this, MainActivity.class);
                startActivity(intentProfile);
                finish();
            }
        });
    }
}
package com.example.ERRANDME;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class ShoppingActivity extends AppCompatActivity {

    private EditText etShopDesc, etShopMPrice;
    private Spinner ShopVehicle;
    private Button btnShopsubmit, btnShopback, clear;
    String myEmail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping);


        etShopDesc = findViewById(R.id.shopDesc);
        etShopMPrice = findViewById(R.id.shopMPrice);
        ShopVehicle = findViewById(R.id.shopVehicle);
        clear = findViewById(R.id.clearShopText);
        btnShopsubmit = findViewById(R.id.btnShopSubmit);
        btnShopback = findViewById(R.id.btnShopBack);

        myEmail = getIntent().getStringExtra("MailingShop");

        addItemsOnSpinner();

        btnShopsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!myEmail.isEmpty() && ! etShopDesc.getText().toString().isEmpty() && !String.valueOf(ShopVehicle.getSelectedItem()).isEmpty() && !etShopMPrice.getText().toString().isEmpty())
                {
                    Intent intentProfile = new Intent(ShoppingActivity.this, MapShoppingActivity.class);
                    intentProfile.putExtra("MailingMapShopping", myEmail);
                    intentProfile.putExtra("OrderingShop",  etShopDesc.getText().toString());
                    intentProfile.putExtra("VehiclingShop", String.valueOf(ShopVehicle.getSelectedItem()));
                    intentProfile.putExtra("PricingShop", etShopMPrice.getText().toString());
                    startActivity(intentProfile);
                    finish();
                }
                else
                {
                    Toast.makeText(ShoppingActivity.this, "Please complete your shopping form!!!", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnShopback.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShoppingActivity.this, ServiceActivity.class);
                intent.putExtra("MailingService", myEmail);
                startActivity(intent);
                finish();
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etShopDesc.setText("");
                etShopMPrice.setText("");
                ShopVehicle.setSelection(0);
            }
        });
    }

    public void addItemsOnSpinner() {

        List<String> list = new ArrayList<String>();
        list.add("Motorcycle");
        list.add("Car");
        list.add("Lorry/Van");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ShopVehicle.setAdapter(dataAdapter);
    }
}
